"""
Save/load management for PyLife game
"""
import json
import streamlit as st
import pickle
import base64
from typing import Dict, Optional

from models import GameState, Character, Relationship, Job, Asset

def save_game(user_id: str, save_name: str, game_state: GameState) -> bool:
    """Save a game state to session storage"""
    try:
        # Get existing saves or initialize empty dict
        all_saves = st.session_state.get('saved_games', {})
        
        # Initialize user's saves if not exists
        if user_id not in all_saves:
            all_saves[user_id] = {}
        
        # Serialize game state to base64
        serialized = pickle.dumps(game_state)
        encoded = base64.b64encode(serialized).decode('utf-8')
        
        # Save to session state
        all_saves[user_id][save_name] = encoded
        st.session_state.saved_games = all_saves
        
        return True
    except Exception as e:
        st.error(f"Error saving game: {str(e)}")
        return False

def load_game(user_id: str, save_name: str) -> Optional[GameState]:
    """Load a game state from session storage"""
    try:
        # Get saves
        all_saves = st.session_state.get('saved_games', {})
        
        # Check if save exists
        if user_id not in all_saves or save_name not in all_saves[user_id]:
            return None
        
        # Deserialize game state
        encoded = all_saves[user_id][save_name]
        serialized = base64.b64decode(encoded)
        game_state = pickle.loads(serialized)
        
        return game_state
    except Exception as e:
        st.error(f"Error loading game: {str(e)}")
        return None

def delete_save(user_id: str, save_name: str) -> bool:
    """Delete a saved game"""
    try:
        # Get saves
        all_saves = st.session_state.get('saved_games', {})
        
        # Check if save exists
        if user_id not in all_saves or save_name not in all_saves[user_id]:
            return False
        
        # Delete save
        del all_saves[user_id][save_name]
        st.session_state.saved_games = all_saves
        
        return True
    except Exception as e:
        st.error(f"Error deleting save: {str(e)}")
        return False

def get_all_saves(user_id: str) -> Dict[str, str]:
    """Get all saved games for a user"""
    # Get saves
    all_saves = st.session_state.get('saved_games', {})
    
    # Return user's saves or empty dict
    return all_saves.get(user_id, {})