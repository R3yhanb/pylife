"""
Game logic for PyLife simulation
"""
import random
from typing import Dict, List, Optional, Tuple, Union

from models import Asset, Character, GameState, Job, Relationship
from events import (
    get_random_event, 
    get_random_initial_relationships, 
    get_career_options, 
    get_assets_for_sale,
    EDUCATION_EVENTS,
    MARRIAGE_EVENTS,
    CHILDREN_EVENTS,
    TRAVEL_EVENTS,
    DISASTER_EVENTS,
    LOTTERY_EVENTS
)

def create_character(name: str, gender: str) -> Character:
    """Create a new character with the given name and gender"""
    return Character(
        name=name,
        gender=gender,
        age_years=13,  # Start at age 13
        age_months=0
    )

def create_random_character() -> Character:
    """Create a random character"""
    male_names = ["James", "John", "Robert", "Michael", "William", "David", "Richard", "Joseph", "Thomas", "Charles"]
    female_names = ["Mary", "Patricia", "Jennifer", "Linda", "Elizabeth", "Barbara", "Susan", "Jessica", "Sarah", "Karen"]
    
    gender = random.choice(["Male", "Female"])
    name = random.choice(male_names if gender == "Male" else female_names)
    
    return Character(
        name=name,
        gender=gender
    )

def initialize_game_state(character: Character) -> GameState:
    """Initialize a new game state with the given character"""
    # Create initial relationships
    relationships_data = get_random_initial_relationships()
    relationships = {}
    for rel_id, rel_data in relationships_data.items():
        relationships[rel_id] = Relationship(
            name=rel_data["name"],
            relationship_type=rel_data["relationship_type"],
            satisfaction=rel_data["satisfaction"]
        )
    
    return GameState(
        character=character,
        relationships=relationships
    )

def apply_event_effects(game_state: GameState, effects: Dict, relationship_key: Optional[str] = None) -> str:
    """Apply event effects to game state and return a summary"""
    summary = []
    
    # Handle character stats
    for stat in ["health", "happiness", "intelligence", "appearance", "money"]:
        if stat in effects:
            old_value = getattr(game_state.character, stat)
            new_value = max(0, old_value + effects[stat])
            setattr(game_state.character, stat, new_value)
            
            if stat == "money":
                change = effects[stat]
                if change > 0:
                    summary.append(f"+${change} money")
                else:
                    summary.append(f"${change} money")
            else:
                change = effects[stat]
                if change > 0:
                    summary.append(f"+{change} {stat}")
                else:
                    summary.append(f"{change} {stat}")
    
    # Handle education updates
    if "education" in effects:
        old_education = game_state.character.education_level
        new_education = effects["education"]
        game_state.character.update_education(new_education)
        game_state.add_event(f"Education changed from {old_education} to {new_education}")
        summary.append(f"Advanced education to {new_education}")
    
    # Handle marriage events
    if "marry" in effects and effects["marry"]:
        # Generate random spouse name
        if game_state.character.gender == "Male":
            spouse_names = ["Mary", "Patricia", "Jennifer", "Linda", "Elizabeth", "Barbara", "Susan", "Jessica", "Sarah", "Karen"]
            spouse_name = random.choice(spouse_names)
        else:
            spouse_names = ["James", "John", "Robert", "Michael", "William", "David", "Richard", "Joseph", "Thomas", "Charles"]
            spouse_name = random.choice(spouse_names)
        
        game_state.character.marry(spouse_name)
        game_state.add_event(f"Got married to {spouse_name}")
        summary.append(f"Got married to {spouse_name}")
        
        # Add spouse as a relationship
        game_state.relationships["spouse"] = Relationship(
            name=spouse_name,
            relationship_type="spouse",
            satisfaction=random.randint(70, 90)
        )
    
    # Handle divorce events
    if "divorce" in effects and effects["divorce"] and game_state.character.is_married:
        ex_spouse = game_state.character.spouse_name
        game_state.character.divorce()
        game_state.add_event(f"Divorced from {ex_spouse}")
        summary.append(f"Divorced from {ex_spouse}")
        
        # Remove spouse from relationships or change relationship type
        if "spouse" in game_state.relationships:
            if random.random() < 0.3:  # 30% chance to remain friends
                game_state.relationships["ex_spouse"] = game_state.relationships["spouse"]
                game_state.relationships["ex_spouse"].relationship_type = "ex_spouse"
                game_state.relationships["ex_spouse"].satisfaction = random.randint(10, 40)
            del game_state.relationships["spouse"]
    
    # Handle children events
    if "add_child" in effects and effects["add_child"] and game_state.character.is_married:
        # Generate child name
        if random.random() < 0.5:  # 50% chance of boy or girl
            child_names = ["James Jr", "John Jr", "Robert Jr", "Michael Jr", "William Jr", "David Jr", "Joseph Jr"]
            child_gender = "Male"
        else:
            child_names = ["Mary Jr", "Patricia Jr", "Jennifer Jr", "Linda Jr", "Elizabeth Jr", "Sarah Jr", "Emma"]
            child_gender = "Female"
        
        child_name = random.choice(child_names)
        game_state.character.add_child(child_name)
        game_state.add_event(f"Had a child: {child_name}")
        summary.append(f"Had a {child_gender.lower()} child named {child_name}")
        
        # Add child as a relationship
        child_id = f"child_{len(game_state.character.children)}"
        game_state.relationships[child_id] = Relationship(
            name=child_name,
            relationship_type="child",
            satisfaction=random.randint(80, 100)
        )
    
    # Handle travel events
    if "visit_country" in effects and effects["visit_country"]:
        country = effects["visit_country"]
        game_state.character.visit_country(country)
        game_state.add_event(f"Visited {country}")
        summary.append(f"Traveled to {country}")
    
    # Handle job effects
    if game_state.job:
        if "job_performance" in effects:
            old_performance = game_state.job.performance
            new_performance = max(0, min(100, old_performance + effects["job_performance"]))
            game_state.job.performance = new_performance
            
            change = effects["job_performance"]
            if change > 0:
                summary.append(f"+{change} job performance")
            else:
                summary.append(f"{change} job performance")
        
        if "promotion" in effects and effects["promotion"]:
            salary_increase = int(game_state.job.salary * 0.2)  # 20% raise
            game_state.job.salary += salary_increase
            game_state.job.title = f"Senior {game_state.job.title}"
            summary.append(f"Promoted to {game_state.job.title} (+${salary_increase}/yr)")
    
    # Handle relationship effects
    if relationship_key and relationship_key in game_state.relationships:
        relationship = game_state.relationships[relationship_key]
        
        for rel_effect in ["family_satisfaction", "friend_satisfaction", f"{relationship_key}_satisfaction"]:
            if rel_effect in effects:
                old_satisfaction = relationship.satisfaction
                new_satisfaction = max(0, min(100, old_satisfaction + effects[rel_effect]))
                relationship.satisfaction = new_satisfaction
                
                change = effects[rel_effect]
                if change > 0:
                    summary.append(f"+{change} relationship with {relationship.name}")
                else:
                    summary.append(f"{change} relationship with {relationship.name}")
    
    # Handle asset effects
    for asset_effect in ["house_value", "car_condition", "assets_condition"]:
        if asset_effect in effects:
            if asset_effect == "house_value":
                for asset in game_state.assets:
                    if asset.category == "house":
                        asset.value += effects[asset_effect]
                        summary.append(f"House value changed by ${effects[asset_effect]}")
                        break
            elif asset_effect == "car_condition":
                for asset in game_state.assets:
                    if asset.category == "car":
                        asset.condition = min(100, asset.condition + effects[asset_effect])
                        summary.append(f"Car condition improved by {effects[asset_effect]}%")
                        break
            elif asset_effect == "assets_condition":
                for asset in game_state.assets:
                    asset.condition = max(0, asset.condition + effects[asset_effect])
                summary.append(f"All assets condition changed by {effects[asset_effect]}%")
    
    return ", ".join(summary)

def get_available_jobs(game_state: GameState) -> List[Dict]:
    """Get list of available jobs based on character's intelligence"""
    if game_state.character.age_years < 18:
        return []
    return get_career_options(game_state.character.intelligence)

def get_school_options() -> List[Dict]:
    """Get list of available schools"""
    return [
        {
            "name": "Public School",
            "cost": 0,
            "intelligence_gain": 3,
            "description": "Standard education with basic curriculum"
        },
        {
            "name": "Private School",
            "cost": 5000,
            "intelligence_gain": 5,
            "description": "Higher quality education with advanced programs"
        },
        {
            "name": "Boarding School",
            "cost": 10000,
            "intelligence_gain": 7,
            "description": "Elite education with comprehensive development"
        }
    ]

def enroll_in_school(game_state: GameState, school: Dict) -> bool:
    """Enroll in selected school"""
    if game_state.character.money < school["cost"]:
        return False
        
    game_state.character.money -= school["cost"]
    game_state.character.intelligence += school["intelligence_gain"]
    game_state.character.education_level = school["name"]
    game_state.add_event(f"Enrolled in {school['name']}")
    return True

def apply_for_job(game_state: GameState, job_data: Dict) -> bool:
    """Apply for a job and return whether application was successful"""
    success_chance = 0.7  # Base 70% chance
    
    # Intelligence affects chance
    if game_state.character.intelligence >= job_data["required_intelligence"] + 20:
        success_chance += 0.2  # Higher intelligence improves chances
    
    # Random chance of success
    if random.random() < success_chance:
        game_state.job = Job(
            title=job_data["title"],
            company=job_data["company"],
            salary=job_data["salary"]
        )
        game_state.add_event(f"Got a job as {job_data['title']} at {job_data['company']}")
        return True
    else:
        game_state.add_event(f"Failed to get a job as {job_data['title']} at {job_data['company']}")
        return False

def quit_job(game_state: GameState) -> str:
    """Quit current job and return a message"""
    if not game_state.job:
        return "You don't have a job to quit!"
    
    job_title = game_state.job.title
    company = game_state.job.company
    game_state.job = None
    
    # Random quit messages
    quit_messages = [
        f"You told your boss at {company} exactly what you thought and stormed out!",
        f"You formally resigned from your position as {job_title}.",
        f"You quietly cleaned out your desk and left {company} forever.",
        f"You sent an email to the entire company announcing your departure from {company}.",
        f"You simply stopped showing up to your {job_title} job."
    ]
    
    selected_message = random.choice(quit_messages)
    game_state.add_event(f"Quit job as {job_title} at {company}")
    
    return selected_message

def get_available_assets(game_state: GameState) -> Dict[str, List[Dict]]:
    """Get assets available for purchase"""
    return get_assets_for_sale()

def purchase_asset(game_state: GameState, asset_data: Dict, category: str) -> bool:
    """Purchase an asset and return whether purchase was successful"""
    if game_state.character.money < asset_data["value"]:
        return False
    
    # Deduct money
    game_state.character.money -= asset_data["value"]
    
    # Add asset
    asset = Asset(
        name=asset_data["name"],
        category=category,
        value=asset_data["value"],
        condition=asset_data["condition"]
    )
    game_state.assets.append(asset)
    game_state.add_event(f"Purchased {asset.name} for ${asset.value}")
    
    return True

def sell_asset(game_state: GameState, asset_index: int) -> int:
    """Sell an asset and return the sale amount"""
    if asset_index >= len(game_state.assets):
        return 0
    
    asset = game_state.assets[asset_index]
    sale_value = int(asset.value * (asset.condition / 100) * random.uniform(0.8, 1.1))
    
    game_state.character.money += sale_value
    game_state.add_event(f"Sold {asset.name} for ${sale_value}")
    
    del game_state.assets[asset_index]
    
    return sale_value

def interact_with_relationship(game_state: GameState, relationship_key: str, interaction_type: str) -> Union[int, Tuple[int, bool]]:
    """Interact with a relationship and return satisfaction change and romance success if applicable"""
    if relationship_key not in game_state.relationships:
        return (0, False) if interaction_type == "flirt" else 0
    
    relationship = game_state.relationships[relationship_key]
    result = relationship.interact(interaction_type)
    
    if interaction_type == "flirt":
        game_state.add_event(f"Flirted with {relationship.name}")
        return result
    else:
        game_state.add_event(interaction_descriptions.get(interaction_type, f"Interacted with {relationship.name}"))
        return result[0] if isinstance(result, tuple) else result
    
    interaction_descriptions = {
        "spend_time": f"Spent time with {relationship.name}",
        "give_gift": f"Gave a gift to {relationship.name}",
        "argue": f"Argued with {relationship.name}",
        "ignore": f"Ignored {relationship.name}"
    }
    
    game_state.add_event(interaction_descriptions.get(interaction_type, f"Interacted with {relationship.name}"))
    
    return change

def add_random_friend(game_state: GameState) -> Optional[str]:
    """Add a random friend and return their name"""
    male_names = ["James", "John", "Robert", "Michael", "William", "David", "Richard", "Joseph", "Thomas", "Charles"]
    female_names = ["Mary", "Patricia", "Jennifer", "Linda", "Elizabeth", "Barbara", "Susan", "Jessica", "Sarah", "Karen"]
    last_names = ["Smith", "Johnson", "Williams", "Jones", "Brown", "Davis", "Miller", "Wilson", "Moore", "Taylor"]
    
    # Randomly generate a friend name
    gender = random.choice(["Male", "Female"])
    first_name = random.choice(male_names if gender == "Male" else female_names)
    last_name = random.choice(last_names)
    full_name = f"{first_name} {last_name}"
    
    # Check if a friend with this name already exists
    friend_keys = [k for k in game_state.relationships.keys() if k.startswith("friend_")]
    for key in friend_keys:
        if game_state.relationships[key].name == full_name:
            return None  # Friend already exists
    
    # Create new friend ID
    new_friend_id = f"friend_{len(friend_keys) + 1}"
    
    # Add new relationship
    game_state.relationships[new_friend_id] = Relationship(
        name=full_name,
        relationship_type="friend",
        satisfaction=random.randint(40, 70)
    )
    
    game_state.add_event(f"Made a new friend: {full_name}")
    
    return full_name

def get_school_options() -> List[Dict]:
    """Get list of available schools"""
    return [
        {
            "name": "Public School",
            "cost": 0,
            "intelligence_gain": 3,
            "description": "Standard education with basic curriculum"
        },
        {
            "name": "Private School",
            "cost": 5000,
            "intelligence_gain": 5,
            "description": "Higher quality education with advanced programs"
        },
        {
            "name": "Boarding School",
            "cost": 10000,
            "intelligence_gain": 7,
            "description": "Elite education with comprehensive development"
        }
    ]

def get_education_options(game_state: GameState) -> List[Dict]:
    """Get available education options based on current education level"""
    education_level = game_state.character.education_level
    options = []
    
    for event in EDUCATION_EVENTS:
        # Check if event has education requirements
        if "requires_education" in event and event["requires_education"] != education_level:
            continue
            
        # Check age requirements if present
        if "min_age" in event and game_state.character.age_years < event["min_age"]:
            continue
        if "max_age" in event and game_state.character.age_years > event["max_age"]:
            continue
            
        options.append(event)
    
    return options

def find_potential_spouse(game_state: GameState) -> Optional[Dict]:
    """Find a potential spouse for the character"""
    # Only available if not already married
    if game_state.character.is_married:
        return None
        
    # Character must be at least 18 years old
    if game_state.character.age_years < 18:
        return None
        
    # Generate potential spouse details
    if game_state.character.gender == "Male":
        first_names = ["Mary", "Patricia", "Jennifer", "Linda", "Elizabeth", "Barbara", "Susan", "Jessica", "Sarah", "Karen"]
        gender = "Female"
    else:
        first_names = ["James", "John", "Robert", "Michael", "William", "David", "Richard", "Joseph", "Thomas", "Charles"]
        gender = "Male"
        
    last_names = ["Smith", "Johnson", "Williams", "Jones", "Brown", "Davis", "Miller", "Wilson", "Moore", "Taylor"]
    
    name = f"{random.choice(first_names)} {random.choice(last_names)}"
    age = game_state.character.age_years + random.randint(-5, 5)
    age = max(18, age)  # Ensure at least 18 years old
    
    return {
        "name": name,
        "gender": gender,
        "age": age,
        "compatibility": random.randint(1, 100),
        "appearance": random.randint(1, 100),
        "wealth": random.randint(1, 100)
    }

def marry_character(game_state: GameState, spouse_data: Dict) -> str:
    """Marry character to specified spouse"""
    if game_state.character.is_married:
        return "You are already married!"
        
    game_state.character.marry(spouse_data["name"])
    
    # Add spouse as a relationship
    game_state.relationships["spouse"] = Relationship(
        name=spouse_data["name"],
        relationship_type="spouse",
        satisfaction=random.randint(70, 90)
    )
    
    message = f"You married {spouse_data['name']}!"
    game_state.add_event(message)
    
    return message

def have_child(game_state: GameState) -> Optional[str]:
    """Have a child if character is married"""
    if not game_state.character.is_married:
        return "You must be married to have a child!"
        
    # Age restrictions
    if game_state.character.age_years < 18 or game_state.character.age_years > 50:
        return "You aren't in the right age range to have children."
        
    # Generate child name
    if random.random() < 0.5:  # 50% chance of boy or girl
        child_names = ["James Jr", "John Jr", "Robert Jr", "Michael Jr", "William Jr", "David Jr", "Joseph Jr"]
        child_gender = "Male"
    else:
        child_names = ["Mary Jr", "Patricia Jr", "Jennifer Jr", "Linda Jr", "Elizabeth Jr", "Sarah Jr", "Emma"]
        child_gender = "Female"
    
    child_name = random.choice(child_names)
    game_state.character.add_child(child_name)
    
    # Add child as a relationship
    child_id = f"child_{len(game_state.character.children)}"
    game_state.relationships[child_id] = Relationship(
        name=child_name,
        relationship_type="child",
        satisfaction=random.randint(80, 100)
    )
    
    message = f"You had a {child_gender.lower()} child named {child_name}!"
    game_state.add_event(f"Had a child: {child_name}")
    
    # Adjust stats
    game_state.character.money -= 2000  # Children are expensive
    game_state.character.happiness += random.randint(5, 15)
    
    return message

def select_travel_destination(game_state: GameState) -> List[Dict]:
    """Get available travel destinations"""
    # List of possible destinations with costs and happiness effects
    destinations = [
        {"country": "France", "cost": 3000, "happiness": 20, "description": "Visit the Eiffel Tower and enjoy French cuisine"},
        {"country": "Japan", "cost": 3500, "happiness": 20, "description": "Experience rich culture and technology in Tokyo"},
        {"country": "Brazil", "cost": 2500, "happiness": 20, "description": "Enjoy beaches and the vibrant city of Rio de Janeiro"},
        {"country": "Egypt", "cost": 2000, "happiness": 18, "description": "See the ancient pyramids and explore Cairo"},
        {"country": "Australia", "cost": 4000, "happiness": 22, "description": "Surf at Bondi Beach and visit the Sydney Opera House"},
        {"country": "Italy", "cost": 2800, "happiness": 19, "description": "Enjoy pizza, pasta, and historic sites in Rome"},
        {"country": "India", "cost": 2200, "happiness": 17, "description": "Experience diverse culture and visit the Taj Mahal"}
    ]
    
    # Filter out already visited countries
    return [d for d in destinations if d["country"] not in game_state.character.visited_countries]

def travel_to_destination(game_state: GameState, destination: Dict) -> str:
    """Travel to the specified destination"""
    country = destination["country"]
    cost = destination["cost"]
    happiness_effect = destination["happiness"]
    
    # Check if enough money
    if game_state.character.money < cost:
        return f"You don't have enough money to travel to {country}. You need ${cost}."
        
    # Apply effects
    game_state.character.money -= cost
    game_state.character.happiness += happiness_effect
    game_state.character.visit_country(country)
    
    message = f"You traveled to {country} and had an amazing experience!"
    game_state.add_event(f"Visited {country}")
    
    return message

def generate_life_summary(game_state: GameState) -> Dict:
    """Generate a summary of the player's life"""
    # Calculate net worth
    net_worth = game_state.character.money
    for asset in game_state.assets:
        net_worth += asset.value
    
    # Get relationship statuses
    relationships = {}
    for key, relationship in game_state.relationships.items():
        relationships[relationship.name] = {
            "type": relationship.relationship_type,
            "satisfaction": relationship.satisfaction
        }
    
    # Determine career success
    career_success = "Unemployed"
    career_income = 0
    if game_state.job:
        career_success = game_state.job.title
        career_income = game_state.job.salary
    
    # Count assets by category
    asset_counts = {"house": 0, "car": 0, "electronics": 0, "antique": 0}
    for asset in game_state.assets:
        asset_counts[asset.category] += 1
    
    # Calculate happiness score (0-10)
    happiness_score = min(10, game_state.character.happiness // 10)
    
    # Calculate health score (0-10)
    health_score = min(10, game_state.character.health // 10)
    
    # Count children and track marriage status
    children_count = len(game_state.character.children)
    marriage_status = "Married" if game_state.character.is_married else "Single"
    if game_state.character.is_married:
        marriage_status = f"Married to {game_state.character.spouse_name}"
    
    # Count visited countries
    countries_visited = len(game_state.character.visited_countries)
    
    # Education level
    education = game_state.character.education_level
    
    return {
        "age": game_state.character.get_age_string(),
        "net_worth": net_worth,
        "career": career_success,
        "annual_income": career_income,
        "education": education,
        "marriage_status": marriage_status,
        "children_count": children_count,
        "countries_visited": countries_visited,
        "relationships": relationships,
        "assets": asset_counts,
        "happiness_score": happiness_score,
        "health_score": health_score,
        "events": game_state.events_history
    }
