"""
Events system for PyLife game
"""
import random
from typing import Dict, List, Tuple

# Education events
EDUCATION_EVENTS = [
    {
        "title": "University Application",
        "description": "You've finished high school. Do you want to apply to university?",
        "choices": ["Apply to university", "Skip higher education"],
        "effects": [
            {"money": -5000, "intelligence": 10, "education": "University Student"},
            {"happiness": -5}
        ],
        "min_age": 18,
        "max_age": 20,
        "requires_education": "High School"
    },
    {
        "title": "Graduate Studies",
        "description": "You've completed your undergraduate degree. Do you want to pursue a graduate degree?",
        "choices": ["Apply for Master's", "Apply for PhD", "Start working"],
        "effects": [
            {"money": -8000, "intelligence": 15, "education": "Master's Student"},
            {"money": -12000, "intelligence": 25, "education": "PhD Student"},
            {"happiness": 5, "education": "Bachelor's Degree"}
        ],
        "min_age": 22,
        "max_age": 30,
        "requires_education": "University Student"
    },
    {
        "title": "Online Course",
        "description": "You found an interesting online course that could enhance your skills.",
        "choices": ["Take the course", "Ignore it"],
        "effects": [
            {"money": -200, "intelligence": 5},
            {}
        ]
    }
]

# Marriage events
MARRIAGE_EVENTS = [
    {
        "title": "Marriage Proposal",
        "description": "Someone has proposed marriage to you!",
        "choices": ["Accept the proposal", "Decline the proposal"],
        "effects": [
            {"happiness": 20, "marry": True},
            {"happiness": -5}
        ],
        "min_age": 22,
        "requires_relationship": "romantic"
    },
    {
        "title": "Marriage Problems",
        "description": "Your marriage is going through a rough patch. How do you handle it?",
        "choices": ["Work on the relationship", "Consider divorce", "Ignore the problems"],
        "effects": [
            {"happiness": 10, "marriage_satisfaction": 15},
            {"happiness": -10, "marriage_satisfaction": -20},
            {"happiness": -5, "marriage_satisfaction": -10}
        ],
        "requires_marriage": True
    },
    {
        "title": "Divorce Decision",
        "description": "Your marriage isn't working out. Do you want to get divorced?",
        "choices": ["File for divorce", "Stay married"],
        "effects": [
            {"happiness": lambda: random.choice([-15, 10]), "money": -5000, "divorce": True},
            {"happiness": -10}
        ],
        "requires_marriage": True,
        "requires_low_marriage_satisfaction": True
    }
]

# Children events
CHILDREN_EVENTS = [
    {
        "title": "Having Children",
        "description": "You and your spouse are considering having a child.",
        "choices": ["Try for a baby", "Not now"],
        "effects": [
            {"happiness": 15, "money": -3000, "add_child": True},
            {"happiness": -5}
        ],
        "requires_marriage": True,
        "min_age": 23,
        "max_age": 45
    },
    {
        "title": "Child's Education",
        "description": "It's time to decide about your child's education.",
        "choices": ["Public school", "Private school", "Homeschooling"],
        "effects": [
            {"happiness": 5},
            {"money": -5000, "happiness": 10},
            {"money": -2000, "happiness": 5, "intelligence": 5}
        ],
        "requires_children": True
    }
]

# Travel events
TRAVEL_EVENTS = [
    {
        "title": "Vacation Opportunity",
        "description": "You have an opportunity to travel abroad for vacation.",
        "choices": ["Travel to Europe", "Travel to Asia", "Travel to South America", "Stay home"],
        "effects": [
            {"money": -3000, "happiness": 20, "health": 10, "visit_country": "France"},
            {"money": -3500, "happiness": 20, "health": 10, "visit_country": "Japan"},
            {"money": -2500, "happiness": 20, "health": 10, "visit_country": "Brazil"},
            {"happiness": -5}
        ]
    },
    {
        "title": "Work Abroad",
        "description": "You have an opportunity to work abroad for a year.",
        "choices": ["Accept the offer", "Decline the offer"],
        "effects": [
            {"money": 5000, "happiness": 15, "job_performance": 10, "visit_country": lambda: random.choice(["UK", "Germany", "Australia", "Canada"])},
            {}
        ],
        "requires_job": True
    },
    {
        "title": "Language Learning",
        "description": "You're considering learning a new language.",
        "choices": ["Take language classes", "Skip it"],
        "effects": [
            {"money": -500, "intelligence": 8, "happiness": 5},
            {}
        ]
    }
]

# Natural disaster events
DISASTER_EVENTS = [
    {
        "title": "Earthquake",
        "description": "A major earthquake has hit your area!",
        "choices": ["Take shelter", "Run outside"],
        "effects": [
            {"health": -5, "happiness": -10, "money": -1000},
            {"health": -15, "happiness": -15, "money": -1000}
        ],
        "probability": 0.01  # Very rare
    },
    {
        "title": "Flood",
        "description": "There's flooding in your neighborhood.",
        "choices": ["Evacuate", "Stay and protect your property"],
        "effects": [
            {"happiness": -5, "money": -500},
            {"health": -10, "money": lambda: random.choice([-2000, -500])}
        ],
        "probability": 0.02  # Rare
    }
]

# Lottery events
LOTTERY_EVENTS = [
    {
        "title": "Lottery Ticket",
        "description": "You see a lottery ticket for sale. The jackpot is huge!",
        "choices": ["Buy a ticket", "Don't bother"],
        "effects": [
            {"money": lambda: random.choices([-10, 100, 1000, 10000, 100000], weights=[85, 10, 3, 1.5, 0.5])[0]},
            {}
        ],
        "probability": 0.1
    }
]

# Career events
CAREER_EVENTS = [
    {
        "title": "Promotion Opportunity",
        "description": "Your boss is impressed with your work and offers you a promotion!",
        "choices": ["Accept promotion", "Decline promotion"],
        "effects": [
            {"happiness": 10, "money": 500, "promotion": True},
            {"happiness": -5}
        ]
    },
    {
        "title": "Workplace Conflict",
        "description": "You're having issues with a coworker. How do you handle it?",
        "choices": ["Talk it out", "Report to HR", "Ignore the situation"],
        "effects": [
            {"happiness": 5, "job_performance": 5},
            {"happiness": -5, "job_performance": 10},
            {"happiness": -10, "job_performance": -10}
        ]
    },
    {
        "title": "Job Training",
        "description": "Your company offers additional training that could advance your career.",
        "choices": ["Take the training", "Skip the training"],
        "effects": [
            {"intelligence": 5, "job_performance": 15, "happiness": -5},
            {"happiness": 5, "job_performance": -5}
        ]
    },
    {
        "title": "Overtime Work",
        "description": "Your boss asks if you can work overtime this month.",
        "choices": ["Accept overtime", "Decline overtime"],
        "effects": [
            {"money": 300, "happiness": -10, "health": -5, "job_performance": 10},
            {"happiness": 5, "job_performance": -5}
        ]
    }
]

# Relationship events
RELATIONSHIP_EVENTS = [
    {
        "title": "Family Reunion",
        "description": "Your family is planning a reunion. Do you attend?",
        "choices": ["Attend reunion", "Skip reunion"],
        "effects": [
            {"happiness": 10, "family_satisfaction": 15},
            {"happiness": 5, "family_satisfaction": -15}
        ]
    },
    {
        "title": "Friend's Birthday",
        "description": "It's your friend's birthday. What do you do?",
        "choices": ["Buy an expensive gift", "Buy a modest gift", "Just send a message"],
        "effects": [
            {"money": -100, "friend_satisfaction": 20},
            {"money": -30, "friend_satisfaction": 10},
            {"friend_satisfaction": -5}
        ]
    },
    {
        "title": "Family Dispute",
        "description": "Your parents are arguing about something and ask for your opinion.",
        "choices": ["Take mom's side", "Take dad's side", "Stay neutral"],
        "effects": [
            {"mother_satisfaction": 15, "father_satisfaction": -15},
            {"mother_satisfaction": -15, "father_satisfaction": 15},
            {"mother_satisfaction": 5, "father_satisfaction": 5}
        ]
    }
]

# Health events
HEALTH_EVENTS = [
    {
        "title": "Common Cold",
        "description": "You've caught a cold. What will you do?",
        "choices": ["Take medicine", "Rest at home", "Ignore it"],
        "effects": [
            {"health": 5, "money": -20},
            {"health": 10, "happiness": -5},
            {"health": -10}
        ]
    },
    {
        "title": "Fitness Opportunity",
        "description": "You're considering starting a new fitness routine.",
        "choices": ["Join a gym", "Exercise at home", "Ignore fitness"],
        "effects": [
            {"health": 15, "money": -50, "appearance": 5},
            {"health": 10, "appearance": 3},
            {"health": -5, "appearance": -2}
        ]
    },
    {
        "title": "Stress Management",
        "description": "You've been feeling stressed lately.",
        "choices": ["Take a vacation", "Meditate daily", "Ignore the stress"],
        "effects": [
            {"health": 15, "happiness": 20, "money": -200},
            {"health": 10, "happiness": 10},
            {"health": -5, "happiness": -10}
        ]
    }
]

# Asset events
ASSET_EVENTS = [
    {
        "title": "Home Renovation",
        "description": "Your home could use some updates. What will you do?",
        "choices": ["Major renovation", "Minor fixes", "Leave it as is"],
        "effects": [
            {"money": -5000, "house_value": 8000, "happiness": 10},
            {"money": -1000, "house_value": 1500, "happiness": 5},
            {"house_value": -500, "happiness": -5}
        ],
        "requires_asset": "house"
    },
    {
        "title": "Car Trouble",
        "description": "Your car is having mechanical issues.",
        "choices": ["Repair at dealership", "Find a cheap mechanic", "Try to fix it yourself"],
        "effects": [
            {"money": -1000, "car_condition": 50},
            {"money": -400, "car_condition": 30},
            {"money": -100, "car_condition": 10, "health": -5}
        ],
        "requires_asset": "car"
    },
    {
        "title": "Investment Opportunity",
        "description": "A friend tells you about an investment opportunity.",
        "choices": ["Invest a lot", "Invest a little", "Don't invest"],
        "effects": [
            {"money": lambda: random.choice([-2000, 3000])},
            {"money": lambda: random.choice([-500, 1000])},
            {}
        ]
    }
]

# Random life events
RANDOM_EVENTS = [
    {
        "title": "Found Money",
        "description": "You found some money on the street!",
        "choices": ["Keep it", "Turn it in to police"],
        "effects": [
            {"money": lambda: random.randint(10, 100), "happiness": 5},
            {"happiness": 10}
        ]
    },
    {
        "title": "Unexpected Bill",
        "description": "You received an unexpected bill in the mail.",
        "choices": ["Pay it", "Contest the bill"],
        "effects": [
            {"money": lambda: -random.randint(100, 500), "happiness": -5},
            {"happiness": -10, "money": lambda: random.choice([0, -random.randint(100, 500)])}
        ]
    },
    {
        "title": "Weather Disaster",
        "description": "A severe storm has damaged some of your property.",
        "choices": ["File insurance claim", "Pay for repairs yourself", "Ignore the damage"],
        "effects": [
            {"money": lambda: random.choice([-100, 500])},
            {"money": -1000},
            {"happiness": -10, "assets_condition": -20}
        ]
    }
]

def get_random_event(game_state) -> Dict:
    """Get a random event appropriate for the current game state"""
    event_pools = []
    
    # Add career events if employed
    if game_state.job:
        event_pools.append(CAREER_EVENTS)
    
    # Add relationship events if has relationships
    if game_state.relationships:
        event_pools.append(RELATIONSHIP_EVENTS)
    
    # Always add health and random events
    event_pools.extend([HEALTH_EVENTS, RANDOM_EVENTS])
    
    # Add asset events if has assets
    if game_state.assets:
        asset_events = []
        for event in ASSET_EVENTS:
            if "requires_asset" in event:
                asset_type = event["requires_asset"]
                if any(asset.category == asset_type for asset in game_state.assets):
                    asset_events.append(event)
            else:
                asset_events.append(event)
        
        if asset_events:
            event_pools.append(asset_events)
    
    # Select a random event pool, then a random event from that pool
    selected_pool = random.choice(event_pools)
    event = random.choice(selected_pool)
    
    # If the event has dynamic effects (using lambdas), evaluate them now
    for i, choice_effects in enumerate(event["effects"]):
        evaluated_effects = {}
        for key, value in choice_effects.items():
            if callable(value):
                evaluated_effects[key] = value()
            else:
                evaluated_effects[key] = value
        event["effects"][i] = evaluated_effects
    
    return event

def get_random_initial_relationships() -> Dict[str, Dict]:
    """Generate random initial relationships"""
    mother_name = random.choice(["Mary", "Susan", "Elizabeth", "Jennifer", "Linda", "Barbara", "Patricia"])
    father_name = random.choice(["John", "Robert", "Michael", "William", "David", "Richard", "Joseph"])
    
    return {
        "mother": {"name": mother_name, "relationship_type": "family", "satisfaction": random.randint(40, 80)},
        "father": {"name": father_name, "relationship_type": "family", "satisfaction": random.randint(40, 80)}
    }

def get_initial_jobs() -> List[Dict]:
    """Get list of initial jobs for player"""
    return [
        {"title": "Fast Food Worker", "company": "Burger Joint", "salary": 1500, "required_intelligence": 0},
        {"title": "Retail Clerk", "company": "Mall Store", "salary": 1800, "required_intelligence": 20},
        {"title": "Office Assistant", "company": "Corporate Inc.", "salary": 2200, "required_intelligence": 40},
        {"title": "Junior Developer", "company": "Tech Startup", "salary": 3200, "required_intelligence": 70},
        {"title": "Sales Associate", "company": "Sales Co.", "salary": 2000, "required_intelligence": 30},
        {"title": "Bank Teller", "company": "National Bank", "salary": 2100, "required_intelligence": 50},
        {"title": "Teacher Assistant", "company": "Local School", "salary": 1900, "required_intelligence": 60}
    ]

def get_career_options(intelligence: int) -> List[Dict]:
    """Get career options based on intelligence"""
    all_jobs = get_initial_jobs()
    return [job for job in all_jobs if job["required_intelligence"] <= intelligence]

def get_assets_for_sale() -> Dict[str, List[Dict]]:
    """Get assets available for purchase by category"""
    return {
        "houses": [
            {"name": "Small Apartment", "value": 80000, "condition": 80},
            {"name": "Suburban House", "value": 180000, "condition": 90},
            {"name": "Urban Condo", "value": 220000, "condition": 95},
            {"name": "Beach House", "value": 350000, "condition": 85},
            {"name": "Country Cottage", "value": 120000, "condition": 75}
        ],
        "cars": [
            {"name": "Used Sedan", "value": 8000, "condition": 70},
            {"name": "New Compact", "value": 18000, "condition": 100},
            {"name": "SUV", "value": 25000, "condition": 90},
            {"name": "Sports Car", "value": 45000, "condition": 100},
            {"name": "Pickup Truck", "value": 30000, "condition": 85}
        ],
        "electronics": [
            {"name": "Smartphone", "value": 800, "condition": 100},
            {"name": "Laptop", "value": 1200, "condition": 100},
            {"name": "Smart TV", "value": 1500, "condition": 100},
            {"name": "Gaming Console", "value": 500, "condition": 100},
            {"name": "Tablet", "value": 600, "condition": 100}
        ],
        "antiques": [
            {"name": "Vintage Watch", "value": 2000, "condition": 60},
            {"name": "Antique Desk", "value": 5000, "condition": 70},
            {"name": "Oil Painting", "value": 8000, "condition": 80},
            {"name": "Rare Book", "value": 1200, "condition": 50},
            {"name": "Vinyl Collection", "value": 3000, "condition": 75}
        ]
    }
