"""
PyLife - A life simulation game built with Streamlit
"""
import random
import streamlit as st
from datetime import datetime
import os
from pathlib import Path
import hashlib

from models import Character, GameState, Asset, Job, Relationship
from game_logic import (
    create_character, 
    create_random_character, 
    initialize_game_state,
    apply_event_effects, 
    get_available_jobs, 
    apply_for_job, 
    quit_job,
    get_available_assets,
    get_education_options,
    find_potential_spouse,
    marry_character,
    have_child,
    select_travel_destination,
    travel_to_destination,
    purchase_asset, 
    sell_asset,
    interact_with_relationship, 
    add_random_friend,
    generate_life_summary,
    get_school_options,
    enroll_in_school
)
from events import get_random_event
from utils import (
    format_currency, 
    format_date, 
    get_progress_color, 
    get_satisfaction_text,
    generate_random_event_message, 
    get_milestone_message,
    get_life_score, 
    get_life_grade
)
from database import (
    init_db, 
    create_user, 
    get_user_by_username, 
    save_game, 
    load_game, 
    get_user_saves, 
    delete_save
)

# Set page config
st.set_page_config(
    page_title="PyLife",
    page_icon="👤",
    layout="wide",
    initial_sidebar_state="collapsed"
)

# Initialize the database
init_db()

# Helper function for password hashing
def hash_password(password):
    """Hash a password for storing."""
    return hashlib.sha256(password.encode()).hexdigest()

# Initialize session state if it doesn't exist
if "game_state" not in st.session_state:
    st.session_state.game_state = None
    st.session_state.game_over = False
    st.session_state.current_event = None
    st.session_state.event_choice = None
    st.session_state.event_result = None
    st.session_state.life_summary = None
    st.session_state.show_career = False
    st.session_state.show_assets = False
    st.session_state.show_relationships = False
    st.session_state.selected_asset_category = None
    st.session_state.message = None
    st.session_state.milestone = None
    st.session_state.month_history = []
    st.session_state.page = "welcome"  # New page state: welcome, login, create_account, character_creation, load_game, or game
    st.session_state.user_id = None
    st.session_state.username = None
    st.session_state.error = None
    st.session_state.save_id = None
    st.session_state.saves_list = None

# Custom CSS for styling
st.markdown("""
<style>
    .main {
        background-color: #cfe2ff; /* Light blue background */
        color: var(--text-color);
    }
    h1, h2, h3 {
        color: var(--text-color);
    }
    p {
        color: var(--text-color);
    }
    .stButton button {
        width: 100%;
        background-color: #3b82f6;
        color: white;
    }
    .stButton button:hover {
        background-color: #2563eb;
    }
    .stat-container {
        border: 1px solid rgba(30, 58, 138, 0.3);
        border-radius: 5px;
        padding: 10px;
        margin-bottom: 10px;
        background-color: rgba(255, 255, 255, 0.6);
    }
    .welcome-container {
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        text-align: center;
        margin: 2rem auto;
        max-width: 800px;
    }
    .welcome-title {
        font-size: 4rem;
        font-weight: bold;
        margin-bottom: 1rem;
        color: #1e3a8a;
    }
    .welcome-slogan {
        font-size: 1.5rem;
        font-style: italic;
        margin-bottom: 2rem;
        color: #334155;
    }
    .footer {
        position: fixed;
        left: 0;
        bottom: 0;
        width: 100%;
        text-align: center;
        padding: 10px;
        font-size: 0.8rem;
        color: #1e293b;
        background-color: rgba(239, 246, 255, 0.7);
    }
    .login-container {
        max-width: 500px;
        margin: 2rem auto;
        padding: 2rem;
        border-radius: 10px;
        background-color: rgba(255, 255, 255, 0.6);
        box-shadow: 0 4px 12px rgba(30, 58, 138, 0.2);
    }
</style>
""", unsafe_allow_html=True)

# Footer with creator info
st.markdown(
    """
    <div class="footer">
    Reyhan Bilaloglus NEA Project
    </div>
    """,
    unsafe_allow_html=True
)

# Main content based on page state
if st.session_state.page == "welcome":
    # Welcome page with improved styling
    st.markdown(
        """
        <style>
        .welcome-container {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            text-align: center;
            margin: 0 auto;
            max-width: 800px;
            padding-top: 2rem;
        }
        .logo-title {
            font-size: 5rem;
            font-weight: bold;
            background: linear-gradient(90deg, #4f46e5, #38bdf8);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            margin-bottom: 0.5rem;
            text-transform: uppercase;
            letter-spacing: 3px;
        }
        .baby-container {
            margin: 2rem 0;
            animation: float 3s ease-in-out infinite;
        }
        @keyframes float {
            0% { transform: translateY(0px); }
            50% { transform: translateY(-10px); }
            100% { transform: translateY(0px); }
        }
        .slogan {
            font-size: 1.8rem;
            font-style: italic;
            color: #a3e635;
            margin-bottom: 2rem;
            text-shadow: 0 0 10px rgba(0,0,0,0.3);
            line-height: 1.5;
        }
        .start-button {
            margin-top: 1rem;
            width: 100%;
        }
        </style>
        <div class="welcome-container">
            <div class="logo-title">PyLife</div>
            <div style="font-size: 1.5rem; color: #334155; margin-bottom: 2rem;">Live the life you have always wanted to live</div>
        </div>
        """,
        unsafe_allow_html=True
    )

    # Button section
    col1, col2 = st.columns(2)
    with col1:
        if st.button("Login", key="login_btn", use_container_width=True):
            st.session_state.page = "login"
            st.rerun()
    with col2:
        if st.button("Sign Up", key="signup_btn", use_container_width=True):
            st.session_state.page = "create_account"
            st.rerun()

elif st.session_state.page == "login":
    # Login page with minimal styling
    st.markdown(
        """
        <style>
        .login-page {
            display: flex;
            flex-direction: column;
            align-items: center;
            padding-top: 2rem;
        }
        .login-title {
            font-size: 3.5rem;
            font-weight: bold;
            background: linear-gradient(90deg, #4f46e5, #38bdf8);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            margin-bottom: 1.5rem;
            text-transform: uppercase;
            letter-spacing: 2px;
            text-align: center;
        }
        .error-message {
            color: #dc2626;
            font-size: 0.9rem;
            margin: 0.5rem 0;
            text-align: center;
        }
        </style>
        <div class="login-page">
            <div class="login-title">PyLife</div>
        </div>
        """,
        unsafe_allow_html=True
    )

    # Show baby image smaller size
    col1, col2, col3 = st.columns([2, 1, 2])
    with col2:
        st.image("static/baby.svg", width=150)

    # Show minimal error message if any
    if st.session_state.error:
        st.markdown(f'<p class="error-message">Error: {st.session_state.error}</p>', unsafe_allow_html=True)
        st.session_state.error = None

    # Login form
    username = st.text_input("Username")
    password = st.text_input("Password", type="password")

    if st.button("Login", use_container_width=True):
        if not username or not password:
            st.session_state.error = "Missing credentials"
            st.rerun()

        # Verify login credentials
        user = get_user_by_username(username)
        if user and user.password_hash == hash_password(password):
            # Login successful
            st.session_state.user_id = user.id
            st.session_state.username = user.username
            st.session_state.saves_list = get_user_saves(user.id)
            st.session_state.page = "load_game" if st.session_state.saves_list else "character_creation"
            st.rerun()
        elif not user:
            st.error(f"Username '{username}' doesn't exist.")
            st.session_state.signup_username = username
            if st.button("Create New Account", use_container_width=True):
                st.session_state.page = "create_account"
                st.rerun()
        else:
            st.session_state.error = "Invalid password"
            st.rerun()

elif st.session_state.page == "create_account":
    # Create account page with improved styling
    st.markdown(
        """
        <style>
        .register-page {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            padding-top: 2rem;
        }
        .register-title {
            font-size: 3.5rem;
            font-weight: bold;
            background: linear-gradient(90deg, #4f46e5, #38bdf8);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            margin-bottom: 1.5rem;
            text-transform: uppercase;
            letter-spacing: 2px;
            text-align: center;
        }
        .register-container {
            background-color: rgba(239, 246, 255, 0.8);
            border-radius: 15px;
            padding: 2rem;
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.2);
            width: 100%;
            max-width: 600px;
            margin: 0 auto;
            border: 1px solid rgba(59, 130, 246, 0.3);
        }
        .register-header {
            color: #1e3a8a;
            text-align: center;
            font-size: 1.8rem;
            margin-bottom: 1.5rem;
            border-bottom: 1px solid rgba(59, 130, 246, 0.3);
            padding-bottom: 1rem;
        }
        </style>
        <div class="register-page">
            <div class="register-title">PyLife</div>
        </div>
        """,
        unsafe_allow_html=True
    )

    # Show baby image smaller size
    col1, col2, col3 = st.columns([2, 1, 2])
    with col2:
        st.image("static/baby.svg", width=120)

    # Show error message if any
    if st.session_state.error:
        st.error(st.session_state.error)
        st.session_state.error = None

    with st.container():
        st.markdown(
            """
            <div class="register-container">
                <h2 class="register-header">Create New Account</h2>
            </div>
            """,
            unsafe_allow_html=True
        )

        col1, col2 = st.columns(2)

        with col1:
            username = st.text_input("Username")
            email = st.text_input("Email (optional)")

        with col2:
            password = st.text_input("Password", type="password")
            confirm_password = st.text_input("Confirm Password", type="password")

        col1, col2 = st.columns(2)

        with col1:
            # Pre-fill username if coming from login page
            if 'signup_username' in st.session_state:
                username = st.session_state.signup_username
                del st.session_state.signup_username

            if st.button("Create Account", use_container_width=True):
                if not username or not password:
                    st.session_state.error = "Username and password are required."
                    st.rerun()

                if password != confirm_password:
                    st.session_state.error = "Passwords do not match."
                    st.rerun()

                # Check if username exists
                existing_user = get_user_by_username(username)
                if existing_user:
                    st.error("This username already exists. Would you like to login instead?")
                    if st.button("Go to Login"):
                        st.session_state.page = "login"
                        st.rerun()
                    st.stop()

                # Create new account
                password_hash = hash_password(password)
                user = create_user(username, password_hash, email)

                # Set session state
                st.session_state.user_id = user.id
                st.session_state.username = user.username
                st.session_state.page = "character_creation"
                st.rerun()

        with col2:
            if st.button("Back to Login", use_container_width=True):
                st.session_state.page = "login"
                st.rerun()

elif st.session_state.page == "load_game":
    # Load game page with improved styling
    st.markdown(
        """
        <style>
        .load-page {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            padding-top: 1rem;
        }
        .load-title {
            font-size: 3rem;
            font-weight: bold;
            background: linear-gradient(90deg, #4f46e5, #38bdf8);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            margin-bottom: 1rem;
            text-transform: uppercase;
            letter-spacing: 2px;
            text-align: center;
        }
        .load-container {
            background-color: rgba(239, 246, 255, 0.8);
            border-radius: 15px;
            padding: 2rem;
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.2);
            width: 100%;
            max-width: 900px;
            margin: 0 auto 2rem auto;
            border: 1px solid rgba(59, 130, 246, 0.3);
        }
        .load-header {
            color: #1e3a8a;
            text-align: center;
            font-size: 1.8rem;
            margin-bottom: 1.5rem;
            border-bottom: 1px solid rgba(59, 130, 246, 0.3);
            padding-bottom: 1rem;
        }
        .welcome-back {
            color: #059669;
            font-size: 1.4rem;
            margin-bottom: 2rem;
            text-align: center;
        }
        .save-item {
            background-color: rgba(224, 242, 254, 0.8);
            border-radius: 12px;
            padding: 1rem;
            margin-bottom: 0.75rem;
            border: 1px solid rgba(59, 130, 246, 0.3);
            transition: all 0.2s ease;
        }
        .save-item:hover {
            background-color: rgba(186, 230, 253, 0.9);
            border-color: rgba(59, 130, 246, 0.5);
        }
        </style>
        <div class="load-page">
            <div class="load-title">PyLife</div>
        </div>
        """,
        unsafe_allow_html=True
    )

    # Show baby image smaller size
    col1, col2, col3 = st.columns([2, 1, 2])
    with col2:
        st.image("static/baby.svg", width=80)

    with st.container():
        st.markdown(
            f"""
            <div class="load-container">
                <h2 class="load-header">Your Saved Lives</h2>
                <div class="welcome-back">Welcome back, {st.session_state.username}!</div>
            </div>
            """,
            unsafe_allow_html=True
        )

        # Show saved games
        if st.session_state.saves_list:
            for save in st.session_state.saves_list:
                with st.expander(f"{save['character_name']} - {save['save_name']} ({save['character_age']})"):
                    st.write(f"**Last played:** {save['last_updated']}")

                    if 'money' in save:
                        st.write(f"**Money:** {format_currency(save['money'])}")

                    col1, col2 = st.columns(2)

                    with col1:
                        if st.button("Load Game", key=f"load_{save['id']}", use_container_width=True):
                            # Load game
                            game_save = load_game(save['id'])
                            if game_save:
                                st.session_state.game_state = game_save.to_game_state()
                                st.session_state.save_id = save['id']
                                st.session_state.month_history = [format_date(st.session_state.game_state.current_date)]
                                st.session_state.page = "game"
                                st.rerun()

                    with col2:
                        if st.button("Delete Save", key=f"delete_{save['id']}", use_container_width=True):
                            # Delete save
                            delete_save(save['id'])
                            st.session_state.saves_list = get_user_saves(st.session_state.user_id)
                            st.rerun()
        else:
            st.info("You don't have any saved games yet. Start a new life!")

        # Options buttons
        col1, col2 = st.columns(2)
        with col1:
            if st.button("Create New Character", use_container_width=True):
                st.session_state.page = "character_creation"
                st.rerun()

        with col2:
            if st.button("Logout", use_container_width=True):
                # Clear session state
                st.session_state.user_id = None
                st.session_state.username = None
                st.session_state.saves_list = None
                st.session_state.page = "welcome"
                st.rerun()

elif st.session_state.page == "character_creation":
    # Character creation page with improved styling
    st.markdown(
        """
        <style>
        .character-page {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            padding-top: 1rem;
        }
        .character-title {
            font-size: 3rem;
            font-weight: bold;
            background: linear-gradient(90deg, #4f46e5, #38bdf8);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            margin-bottom: 1rem;
            text-transform: uppercase;
            letter-spacing: 2px;
            text-align: center;
        }
        .character-container {
            background-color: rgba(239, 246, 255, 0.8);
            border-radius: 15px;
            padding: 2rem;
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.2);
            width: 100%;
            max-width: 800px;
            margin: 0 auto 2rem auto;
            border: 1px solid rgba(59, 130, 246, 0.3);
        }
        .character-header {
            color: #1e3a8a;
            text-align: center;
            font-size: 1.8rem;
            margin-bottom: 1.5rem;
            border-bottom: 1px solid rgba(59, 130, 246, 0.3);
            padding-bottom: 1rem;
        }
        .character-option {
            background-color: rgba(224, 242, 254, 0.8);
            border-radius: 12px;
            padding: 1.5rem;
            margin-bottom: 1rem;
            border: 1px solid rgba(59, 130, 246, 0.3);
        }
        .character-option-title {
            color: #0369a1;
            font-size: 1.2rem;
            margin-bottom: 1rem;
            text-align: center;
            font-weight: bold;
        }
        </style>
        <div class="character-page">
            <div class="character-title">PyLife</div>
        </div>
        """,
        unsafe_allow_html=True
    )

    # Show baby image smaller size
    col1, col2, col3 = st.columns([2, 1, 2])
    with col2:
        st.image("static/baby.svg", width=100)

    with st.container():
        st.markdown(
            """
            <div class="character-container">
                <h2 class="character-header">Create Your Character</h2>
            </div>
            """,
            unsafe_allow_html=True
        )

        col1, col2 = st.columns(2)

        with col1:
            st.markdown(
                """
                <div class="character-option">
                    <div class="character-option-title">Custom Character</div>
                </div>
                """,
                unsafe_allow_html=True
            )
            name = st.text_input("Character Name")
            gender = st.selectbox("Gender", ["Male", "Female"])

            if st.button("Create Character", use_container_width=True):
                if name:
                    character = create_character(name, gender)
                    st.session_state.game_state = initialize_game_state(character)
                    st.session_state.month_history = [format_date(st.session_state.game_state.current_date)]
                    st.session_state.page = "game"
                    st.rerun()

        with col2:
            st.markdown(
                """
                <div class="character-option">
                    <div class="character-option-title">Random Character</div>
                </div>
                """,
                unsafe_allow_html=True
            )
            st.write("Let the game generate a random character with random traits and attributes.")
            st.write("")
            st.write("")

            if st.button("Generate Random Character", use_container_width=True):
                character = create_random_character()
                st.session_state.game_state = initialize_game_state(character)
                st.session_state.month_history = [format_date(st.session_state.game_state.current_date)]
                st.session_state.page = "game"
                st.rerun()

        # Back button
        if st.button("Back to Main Menu", use_container_width=True):
            if st.session_state.user_id:
                st.session_state.page = "load_game"
                st.session_state.saves_list = get_user_saves(st.session_state.user_id)
            else:
                st.session_state.page = "login"
            st.rerun()

# Main game content
elif st.session_state.page == "game":
    # Game header with baby image
    col1, col2 = st.columns([0.1, 0.9])
    with col1:
        st.image("static/baby.svg", width=50)
    with col2:
        st.markdown("""
            <h1 style="color: var(--text-color);">PyLife</h1>
            """, unsafe_allow_html=True)

    # Add a Save Game button in the sidebar if user is logged in
    if st.session_state.user_id:
        with st.sidebar:
            st.markdown("### Game Options")

            save_name = st.text_input("Save Name", value=f"{st.session_state.game_state.character.name}'s Life")

            if st.button("Save Game"):
                if save_name:
                    # Save the game
                    save_id = save_game(st.session_state.game_state, st.session_state.user_id, save_name)
                    st.session_state.save_id = save_id
                    st.success(f"Game saved as '{save_name}'!")

            if st.button("Back to Main Menu"):
                st.session_state.page = "load_game"
                st.session_state.saves_list = get_user_saves(st.session_state.user_id)
                st.rerun()

    # Game screen
    game_state = st.session_state.game_state
    character = game_state.character

    # Check if game is over
    if st.session_state.game_over:
        st.subheader("Life Summary")

        summary = st.session_state.life_summary
        score = get_life_score(summary)
        grade = get_life_grade(score)

        col1, col2 = st.columns(2)

        with col1:
            st.markdown(f"### {character.name}'s Life")
            st.write(f"**Final Age:** {summary['age']}")
            st.write(f"**Net Worth:** {format_currency(summary['net_worth'])}")
            st.write(f"**Career:** {summary['career']}")
            st.write(f"**Annual Income:** {format_currency(summary['annual_income'])}")

            st.markdown("### Assets")
            for category, count in summary['assets'].items():
                st.write(f"**{category.title()}s:** {count}")

            st.markdown("### Life Score")
            st.write(f"**Score:** {score}/100")
            st.write(f"**Grade:** {grade}")

        with col2:
            st.markdown("### Relationships")
            for name, rel in summary['relationships'].items():
                satisfaction = rel['satisfaction']
                st.write(f"**{name} ({rel['type']}):** {get_satisfaction_text(satisfaction)}")

            st.markdown("### Life Events")
            for event in summary['events'][-10:]:  # Show last 10 events
                st.write(f"- {event}")

        col1, col2 = st.columns(2)

        with col1:
            if st.button("New Life"):
                st.session_state.game_state = None
                st.session_state.game_over = False
                st.session_state.life_summary = None
                st.session_state.page = "character_creation"
                st.rerun()

        with col2:
            if st.button("Back to Main Menu") and st.session_state.user_id:
                st.session_state.page = "load_game"
                st.session_state.saves_list = get_user_saves(st.session_state.user_id)
                st.rerun()

    else:
        # Layout for game screen
        col1, col2 = st.columns([3, 2])

        with col1:
            # Character info and main game area
            st.subheader(f"{character.name}'s Life")

            # Stats row
            stats_col1, stats_col2, stats_col3, stats_col4 = st.columns(4)

            with stats_col1:
                st.markdown(f"**Age**: {character.get_age_string()}")
                st.markdown(f"**Birthday**: {character.get_birthday()}")

            with stats_col2:
                st.markdown(f"**Gender**: {character.gender}")
                st.markdown(f"**Current Date**: {format_date(game_state.current_date)}")

            with stats_col3:
                st.markdown(f"**Money**: {format_currency(character.money)}")
                if game_state.job:
                    st.markdown(f"**Job**: {game_state.job.title}")
                else:
                    st.markdown("**Job**: Unemployed")

            with stats_col4:
                st.markdown(f"**Assets**: {len(game_state.assets)}")
                st.markdown(f"**Relationships**: {len(game_state.relationships)}")

            # Progress bars for stats
            st.markdown("### Stats")
            stats_bars_col1, stats_bars_col2 = st.columns(2)

            with stats_bars_col1:
                st.markdown("**Health**")
                st.progress(character.health / 100, text=f"{character.health}%")

                st.markdown("**Intelligence**")
                st.progress(character.intelligence / 100, text=f"{character.intelligence}%")

            with stats_bars_col2:
                st.markdown("**Happiness**")
                st.progress(character.happiness / 100, text=f"{character.happiness}%")

                st.markdown("**Appearance**")
                st.progress(character.appearance / 100, text=f"{character.appearance}%")

            # Events section
            st.markdown("### Events")

            # Show milestone if any
            if st.session_state.milestone:
                st.info(st.session_state.milestone)
                st.session_state.milestone = None

            # Show message if any
            if st.session_state.message:
                st.success(st.session_state.message)
                st.session_state.message = None

            # Handle current event
            if st.session_state.current_event:
                event = st.session_state.current_event

                st.markdown(f"#### {event['title']}")
                st.write(event['description'])

                #Show event choices
                if st.session_state.event_choice is None:
                    for i, choice in enumerate(event['choices']):
                        if st.button(f"{choice}", key=f"choice_{i}"):
                            st.session_state.event_choice = i
                            effects = event['effects'][i]
                            result_summary = apply_event_effects(game_state, effects)
                            st.session_state.event_result = result_summary
                            break

                # Show event result
                if st.session_state.event_result is not None:
                    st.success(f"Result: {st.session_state.event_result}")
                    if st.button("Continue", key="continue_event"):
                        st.session_state.current_event = None
                        st.session_state.event_choice = None
                        st.session_state.event_result = None
                        st.rerun()

            # Time controls
            st.markdown("### Time")
            time_col1, time_col2, time_col3 = st.columns(3)

            with time_col1:
                if st.button("Age Up 1 Month", disabled=st.session_state.current_event is not None):
                    # Advance time
                    is_birthday, game_over, old_date = game_state.advance_time(1)

                    # Check for milestone
                    milestone = get_milestone_message(character.age_years, character.age_months)
                    if milestone:
                        st.session_state.milestone = milestone

                    # Update month history
                    st.session_state.month_history.append(format_date(game_state.current_date))

                    # Always generate new event when no current event
                    if not game_over and st.session_state.current_event is None:
                        st.session_state.current_event = get_random_event(game_state)
                    else:
                        st.session_state.message = generate_random_event_message()

                    # Check if game over
                    if game_over:
                        st.session_state.game_over = True
                        st.session_state.life_summary = generate_life_summary(game_state)

                    st.rerun()

            with time_col2:
                if st.button("Age Up 1 Year", disabled=st.session_state.current_event is not None):
                    # Store old values
                    old_money = character.money

                    # Advance time for 12 months
                    final_birthday = False
                    final_game_over = False

                    for i in range(12):
                        is_birthday, game_over, old_date = game_state.advance_time(1)
                        if is_birthday:
                            final_birthday = True
                        if game_over:
                            final_game_over = True
                            break

                        # Update month history
                        st.session_state.month_history.append(format_date(game_state.current_date))

                    # Check for milestone
                    milestone = get_milestone_message(character.age_years, character.age_months)
                    if milestone:
                        st.session_state.milestone = milestone

                    # Show summary of the year
                    money_change = character.money - old_money
                    if money_change >= 0:
                        st.session_state.message = f"A year has passed. You earned {format_currency(money_change)}."
                    else:
                        st.session_state.message = f"A year has passed. You lost {format_currency(abs(money_change))}."

                    # Generate random event 70% of the time if no current event
                    if not final_game_over and st.session_state.current_event is None and random.random() < 0.7:
                        st.session_state.current_event = get_random_event(game_state)

                    # Check if game over
                    if final_game_over:
                        st.session_state.game_over = True
                        st.session_state.life_summary = generate_life_summary(game_state)

                    st.rerun()

            with time_col3:
                if st.button("End Life", disabled=st.session_state.current_event is not None):
                    st.session_state.game_over = True
                    st.session_state.life_summary = generate_life_summary(game_state)
                    st.rerun()

        with col2:
            # Separate sections for life aspects

            # School/Career section based on age
            if character.age_years < 18:
                st.markdown("## School")
                if character.education_level:
                    st.write(f"**Current School:** {character.education_level}")
                else:
                    st.write("You are not enrolled in any school.")

                if st.button("Look for Schools"):
                    available_schools = get_school_options()
                    st.session_state.available_schools = available_schools
                    st.rerun()

                # Show school listings if looking for a school
                if "available_schools" in st.session_state:
                    st.markdown("### School Options")
                    for i, school in enumerate(st.session_state.available_schools):
                        with st.expander(f"{school['name']} - Cost: {format_currency(school['cost'])}"):
                            st.write(school['description'])
                            st.write(f"Intelligence Gain: +{school['intelligence_gain']}")

                            if st.button("Enroll", key=f"enroll_school_{i}"):
                                success = enroll_in_school(game_state, school)
                                if success:
                                    st.session_state.message = f"You enrolled in {school['name']}!"
                                else:
                                    st.session_state.message = "You don't have enough money for this school!"

                                if "available_schools" in st.session_state:
                                    del st.session_state.available_schools

                                st.rerun()
            else:
                st.markdown("## Career")

                if game_state.job:
                    st.write(f"**Current Job:** {game_state.job.title} at {game_state.job.company}")
                    st.write(f"**Salary:** {format_currency(game_state.job.salary)}/year")
                    st.write(f"**Experience:** {game_state.job.years_experience:.1f} years")

                    st.markdown("**Performance**")
                    st.progress(game_state.job.performance / 100, text=f"{game_state.job.performance}%")

                    if st.button("Work Hard"):
                        change = game_state.job.work_hard()
                        st.session_state.message = f"You worked hard and increased your performance by {change}%."
                        st.rerun()

                    if st.button("Quit Job"):
                        message = quit_job(game_state)
                        st.session_state.message = message
                        st.rerun()
                else:
                    st.write("You are currently unemployed.")

                    if st.button("Find a Job"):
                        available_jobs = get_available_jobs(game_state)
                        st.session_state.available_jobs = available_jobs
                        st.rerun()

            # Show job listings if looking for a job
            if not game_state.job and "available_jobs" in st.session_state:
                st.markdown("### Job Listings")

                for i, job in enumerate(st.session_state.available_jobs):
                    with st.expander(f"{job['title']} at {job['company']} - {format_currency(job['salary'])}/year"):
                        st.write(f"Required Intelligence: {job['required_intelligence']}")
                        st.write(f"Your Intelligence: {character.intelligence}")

                        if st.button("Apply", key=f"apply_job_{i}"):
                            success = apply_for_job(game_state, job)
                            if success:
                                st.session_state.message = f"You got the job as {job['title']} at {job['company']}!"
                            else:
                                st.session_state.message = f"Your application for {job['title']} was rejected."

                            if "available_jobs" in st.session_state:
                                del st.session_state.available_jobs

                            st.rerun()

            # Relationships section
            st.markdown("## Relationships")

            # Add friend button
            if st.button("Make New Friend", disabled=st.session_state.current_event is not None):
                friend_name = add_random_friend(game_state)
                if friend_name:
                    st.session_state.message = f"You made a new friend: {friend_name}"
                else:
                    st.session_state.message = "You tried to make a friend but were unsuccessful."
                st.rerun()

            # List relationships
            for rel_id, relationship in game_state.relationships.items():
                with st.expander(f"{relationship.name} ({relationship.relationship_type.title()})"):
                    st.write(f"Satisfaction: {relationship.satisfaction}%")
                    st.progress(relationship.satisfaction / 100)
                    st.write(f"Status: {get_satisfaction_text(relationship.satisfaction)}")

                    # Interaction buttons
                    col1, col2 = st.columns(2)
                    with col1:
                        if st.button(f"Spend Time", key=f"spend_{rel_id}"):
                            change = interact_with_relationship(game_state, rel_id, "spend_time")
                            st.session_state.message = f"You spent time with {relationship.name}. Relationship {'+' if change > 0 else ''}{change}%"
                            st.rerun()

                        if st.button(f"Argue", key=f"argue_{rel_id}"):
                            change = interact_with_relationship(game_state, rel_id, "argue")
                            st.session_state.message = f"You argued with {relationship.name}. Relationship {'+' if change > 0 else ''}{change}%"
                            st.rerun()

                        if relationship.relationship_type == "friend" and st.button(f"Flirt", key=f"flirt_{rel_id}"):
                            change, romance_success = interact_with_relationship(game_state, rel_id, "flirt")
                            if romance_success:
                                st.session_state.message = f"You flirted with {relationship.name} and they became your romantic partner! Relationship {'+' if change > 0 else ''}{change}%"
                            else:
                                st.session_state.message = f"You flirted with {relationship.name}. Relationship {'+' if change > 0 else ''}{change}%"
                            st.rerun()

                    with col2:
                        if st.button(f"Give Gift", key=f"gift_{rel_id}"):
                            if character.money >= 50:
                                character.money -= 50
                                change = interact_with_relationship(game_state, rel_id, "give_gift")
                                st.session_state.message = f"You gave a gift to {relationship.name} ($50). Relationship {'+' if change > 0 else ''}{change}%"
                            else:
                                st.session_state.message = "You don't have enough money for a gift."
                            st.rerun()

                        if st.button(f"Ignore", key=f"ignore_{rel_id}"):
                            change = interact_with_relationship(game_state, rel_id, "ignore")
                            st.session_state.message = f"You ignored {relationship.name}. Relationship {'+' if change > 0 else ''}{change}%"
                            st.rerun()

            # Assets section
            st.markdown("## Assets")

            # Show owned assets
            if game_state.assets:
                st.markdown("#### Your Assets")
                for i, asset in enumerate(game_state.assets):
                    with st.expander(f"{asset.name} ({asset.category.title()})"):
                        st.write(f"Value: {format_currency(asset.value)}")
                        st.write(f"Condition: {asset.condition}%")

                        if st.button(f"Sell for {format_currency(int(asset.value * (asset.condition / 100)))}", key=f"sell_asset_{i}"):
                            sale_amount = sell_asset(game_state, i)
                            st.session_state.message = f"You sold {asset.name} for {format_currency(sale_amount)}."
                            st.rerun()

            else:
                st.write("You don't own any assets yet.")

            # Button to browse assets for sale
            if st.button("Go Shopping", disabled=st.session_state.current_event is not None):
                assets_for_sale = get_available_assets(game_state)
                st.session_state.assets_for_sale = assets_for_sale
                st.session_state.selected_asset_category = "houses"
                st.rerun()

            # Show assets for sale if shopping
            if "assets_for_sale" in st.session_state:
                st.markdown("#### Shop for Assets")

                # Category selection
                category = st.radio(
                    "Category",
                    ["houses", "cars", "electronics", "antiques"],
                    index=["houses", "cars", "electronics", "antiques"].index(st.session_state.selected_asset_category)
                )

                if category != st.session_state.selected_asset_category:
                    st.session_state.selected_asset_category = category
                    st.rerun()

                # Display assets in selected category
                for i, asset in enumerate(st.session_state.assets_for_sale[category]):
                    with st.expander(f"{asset['name']} - {format_currency(asset['value'])}"):
                        st.write(f"Condition: {asset['condition']}%")

                        if st.button(f"Buy for {format_currency(asset['value'])}", key=f"buy_asset_{category}_{i}"):
                            if character.money >= asset['value']:
                                success = purchase_asset(game_state, asset, category[:-1])  # Remove 's' from category
                                if success:
                                    st.session_state.message = f"You purchased {asset['name']} for {format_currency(asset['value'])}."
                                else:
                                    st.session_state.message = "Failed to purchase asset."
                            else:
                                st.session_state.message = "You don't have enough money!"
                            st.rerun()

                # Exit shopping button
                if st.button("Exit Shopping"):
                    del st.session_state.assets_for_sale
                    del st.session_state.selected_asset_category
                    st.rerun()

            # Events History section
            st.markdown("## Events History")

            # Show timeline of months
            st.markdown("#### Timeline")
            st.write(", ".join(st.session_state.month_history[-12:]))  # Show last 12 months

            # Show event history
            st.markdown("#### Events")
            for event in game_state.events_history[-10:]:  # Show last 10 events
                st.write(f"- {event}")

# Footer
st.markdown("---")
st.markdown("PyLife - Reyhan Bilaloglus NEA Project")