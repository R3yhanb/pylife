"""
Database module for PyLife game
"""
import os
from typing import Dict, List, Optional, Tuple
import json
from datetime import datetime

from sqlalchemy import create_engine, Column, Integer, String, Float, Text, Boolean, DateTime, ForeignKey
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, relationship

# Database setup
DATABASE_URL = os.environ.get("DATABASE_URL")
if DATABASE_URL and DATABASE_URL.startswith("postgres://"):
    DATABASE_URL = DATABASE_URL.replace("postgres://", "postgresql://", 1)

engine = create_engine(DATABASE_URL)
Session = sessionmaker(bind=engine)
Base = declarative_base()

class User(Base):
    __tablename__ = "users"
    
    id = Column(Integer, primary_key=True)
    username = Column(String(50), unique=True, nullable=False)
    password_hash = Column(String(100), nullable=False)
    email = Column(String(100), unique=True, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    
    # Relationships
    games = relationship("GameSave", back_populates="user", cascade="all, delete-orphan")
    
    def __repr__(self):
        return f"<User(username='{self.username}')>"


class GameSave(Base):
    __tablename__ = "game_saves"
    
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    save_name = Column(String(100), nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)
    last_updated = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Character data
    character_name = Column(String(100), nullable=False)
    character_gender = Column(String(20), nullable=False)
    character_age_years = Column(Integer, default=18)
    character_age_months = Column(Integer, default=0)
    character_birth_month = Column(Integer)
    character_birth_day = Column(Integer)
    character_health = Column(Integer, default=100)
    character_happiness = Column(Integer, default=50)
    character_intelligence = Column(Integer)
    character_appearance = Column(Integer)
    character_money = Column(Integer, default=1000)
    character_education = Column(String(50), default="High School")
    character_is_married = Column(Boolean, default=False)
    character_spouse_name = Column(String(100), nullable=True)
    character_children = Column(Text, default="[]")  # JSON serialized array
    character_visited_countries = Column(Text, default="[]")  # JSON serialized array
    
    # Serialized game state data
    current_date = Column(DateTime)
    relationships_data = Column(Text)  # JSON serialized
    job_data = Column(Text)  # JSON serialized
    assets_data = Column(Text)  # JSON serialized
    events_history = Column(Text)  # JSON serialized
    month_history = Column(Text)  # JSON serialized
    
    # Relationships
    user = relationship("User", back_populates="games")
    
    def __repr__(self):
        return f"<GameSave(id={self.id}, user_id={self.user_id}, character_name='{self.character_name}')>"
    
    def to_game_state(self):
        """Convert database record to a GameState object"""
        from models import Character, GameState, Relationship, Job, Asset
        
        # Create character
        character = Character(
            name=self.character_name,
            gender=self.character_gender,
            age_years=self.character_age_years,
            age_months=self.character_age_months,
            birth_month=self.character_birth_month,
            birth_day=self.character_birth_day,
            health=self.character_health,
            happiness=self.character_happiness,
            intelligence=self.character_intelligence,
            appearance=self.character_appearance,
            money=self.character_money,
            education_level=self.character_education,
            is_married=self.character_is_married,
            spouse_name=self.character_spouse_name
        )
        
        # Load children
        if self.character_children:
            character.children = json.loads(self.character_children)
            
        # Load visited countries
        if self.character_visited_countries:
            character.visited_countries = set(json.loads(self.character_visited_countries))
        
        # Create game state
        game_state = GameState(character=character)
        
        # Set current date
        game_state.current_date = self.current_date
        
        # Load relationships
        if self.relationships_data:
            relationships_dict = json.loads(self.relationships_data)
            for rel_id, rel_data in relationships_dict.items():
                game_state.relationships[rel_id] = Relationship(
                    name=rel_data["name"],
                    relationship_type=rel_data["relationship_type"],
                    satisfaction=rel_data["satisfaction"]
                )
        
        # Load job
        if self.job_data:
            job_data = json.loads(self.job_data)
            if job_data:
                game_state.job = Job(
                    title=job_data["title"],
                    company=job_data["company"],
                    salary=job_data["salary"],
                    performance=job_data["performance"],
                    years_experience=job_data["years_experience"]
                )
        
        # Load assets
        if self.assets_data:
            assets_list = json.loads(self.assets_data)
            for asset_data in assets_list:
                game_state.assets.append(Asset(
                    name=asset_data["name"],
                    category=asset_data["category"],
                    value=asset_data["value"],
                    condition=asset_data["condition"]
                ))
        
        # Load events history
        if self.events_history:
            game_state.events_history = json.loads(self.events_history)
        
        return game_state
    
    @classmethod
    def from_game_state(cls, game_state, user_id, save_name=None):
        """Create a GameSave instance from a GameState object"""
        from models import GameState
        
        if not isinstance(game_state, GameState):
            raise TypeError("game_state must be a GameState instance")
        
        character = game_state.character
        
        # Create a new GameSave instance
        game_save = cls(
            user_id=user_id,
            save_name=save_name or f"{character.name}'s Life",
            character_name=character.name,
            character_gender=character.gender,
            character_age_years=character.age_years,
            character_age_months=character.age_months,
            character_birth_month=character.birth_month,
            character_birth_day=character.birth_day,
            character_health=character.health,
            character_happiness=character.happiness,
            character_intelligence=character.intelligence,
            character_appearance=character.appearance,
            character_money=character.money,
            character_education=character.education_level,
            character_is_married=character.is_married,
            character_spouse_name=character.spouse_name,
            character_children=json.dumps(character.children),
            character_visited_countries=json.dumps(list(character.visited_countries)),
            current_date=game_state.current_date
        )
        
        # Serialize relationships
        if game_state.relationships:
            relationships_dict = {}
            for rel_id, relationship in game_state.relationships.items():
                relationships_dict[rel_id] = {
                    "name": relationship.name,
                    "relationship_type": relationship.relationship_type,
                    "satisfaction": relationship.satisfaction
                }
            game_save.relationships_data = json.dumps(relationships_dict)
        
        # Serialize job
        if game_state.job:
            job_data = {
                "title": game_state.job.title,
                "company": game_state.job.company,
                "salary": game_state.job.salary,
                "performance": game_state.job.performance,
                "years_experience": game_state.job.years_experience
            }
            game_save.job_data = json.dumps(job_data)
        
        # Serialize assets
        if game_state.assets:
            assets_list = []
            for asset in game_state.assets:
                assets_list.append({
                    "name": asset.name,
                    "category": asset.category,
                    "value": asset.value,
                    "condition": asset.condition
                })
            game_save.assets_data = json.dumps(assets_list)
        
        # Serialize events history
        if game_state.events_history:
            game_save.events_history = json.dumps(game_state.events_history)
        
        return game_save


# Database functions
def init_db():
    """Initialize the database by creating all tables"""
    Base.metadata.create_all(engine)


def create_user(username: str, password_hash: str, email: Optional[str] = None) -> User:
    """Create a new user and return the User object"""
    session = Session()
    # Convert empty string to None for email
    email = email if email else None
    user = User(username=username, password_hash=password_hash, email=email)
    session.add(user)
    session.commit()
    user_id = user.id
    session.close()
    return user


def get_user_by_username(username: str) -> Optional[User]:
    """Get a user by username, or None if not found"""
    session = Session()
    user = session.query(User).filter(User.username == username).first()
    session.close()
    return user


def save_game(game_state, user_id: int, save_name: Optional[str] = None) -> int:
    """Save a game state to the database and return the save ID"""
    session = Session()
    
    # Check if a save with this name already exists
    if save_name:
        existing_save = session.query(GameSave).filter(
            GameSave.user_id == user_id,
            GameSave.save_name == save_name
        ).first()
        
        if existing_save:
            # Update existing save
            game_save = GameSave.from_game_state(game_state, user_id, save_name)
            for key, value in game_save.__dict__.items():
                if key != '_sa_instance_state' and key != 'id':
                    setattr(existing_save, key, value)
            save_id = existing_save.id
        else:
            # Create new save
            game_save = GameSave.from_game_state(game_state, user_id, save_name)
            session.add(game_save)
            session.flush()
            save_id = game_save.id
    else:
        # Create new save with default name
        game_save = GameSave.from_game_state(game_state, user_id)
        session.add(game_save)
        session.flush()
        save_id = game_save.id
    
    session.commit()
    session.close()
    return save_id


def load_game(save_id: int) -> Optional[GameSave]:
    """Load a game save by ID, or None if not found"""
    session = Session()
    game_save = session.query(GameSave).filter(GameSave.id == save_id).first()
    session.close()
    return game_save


def get_user_saves(user_id: int) -> List[Dict]:
    """Get a list of all saves for a user"""
    session = Session()
    saves = session.query(GameSave).filter(GameSave.user_id == user_id).all()
    result = []
    for save in saves:
        result.append({
            "id": save.id,
            "save_name": save.save_name,
            "character_name": save.character_name,
            "character_age": f"{save.character_age_years} years, {save.character_age_months} months",
            "last_updated": save.last_updated
        })
    session.close()
    return result


def delete_save(save_id: int) -> bool:
    """Delete a save by ID, return True if successful"""
    session = Session()
    save = session.query(GameSave).filter(GameSave.id == save_id).first()
    if save:
        session.delete(save)
        session.commit()
        session.close()
        return True
    session.close()
    return False