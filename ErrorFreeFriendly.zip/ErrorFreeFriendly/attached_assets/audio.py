
import pygame
import streamlit as st

def init_audio():
    """Initialize audio system"""
    try:
        pygame.mixer.quit()  # Clean up any existing mixer
        pygame.mixer.init(frequency=44100, size=-16, channels=2, buffer=2048)
        if 'background_music' not in st.session_state:
            st.session_state.background_music = True
        if 'theme' not in st.session_state:
            st.session_state.theme = 'dark'
    except Exception as e:
        st.error(f"Audio initialization error: {str(e)}")

def toggle_music():
    """Toggle background music on/off"""
    if st.session_state.background_music:
        pygame.mixer.music.load('static/game-music-player-console-8bit-background-intro-theme-297305.mp3')
        pygame.mixer.music.play(-1)  # -1 means loop indefinitely
    else:
        pygame.mixer.music.stop()
