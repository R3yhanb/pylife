"""
Audio module for PyLife game
"""
import pygame
import streamlit as st

def init_audio():
    """Initialize audio system"""
    try:
        pygame.mixer.quit()  # Clean up any existing mixer
        pygame.mixer.init(frequency=44100, size=-16, channels=2, buffer=2048)
        if 'background_music' not in st.session_state:
            st.session_state.background_music = True
        if 'theme' not in st.session_state:
            st.session_state.theme = 'dark'
    except Exception as e:
        st.error(f"Audio initialization error: {str(e)}")

def toggle_music():
    """Toggle background music on/off"""
    try:
        if st.session_state.background_music:
            # Check if music is loaded and play
            try:
                pygame.mixer.music.play(-1)  # -1 means loop indefinitely
            except:
                # Initialize mixer if needed
                pygame.mixer.init()
                st.warning("Music file not found. Using default audio.")
        else:
            # Stop music if it's playing
            try:
                pygame.mixer.music.stop()
            except:
                pass
    except Exception as e:
        st.error(f"Error toggling music: {str(e)}")