"""
Utility functions for PyLife game
"""
import random
from datetime import datetime
from typing import List, Dict

def format_currency(amount: int) -> str:
    """Format an integer as currency"""
    return f"${amount:,}"

def format_date(date: datetime) -> str:
    """Format a datetime object as a date string"""
    return date.strftime("%B %d, %Y")

def get_progress_color(value: int) -> str:
    """Get a color for progress bars based on value (0-100)"""
    if value >= 80:
        return "green"
    elif value >= 50:
        return "orange"
    else:
        return "red"

def get_satisfaction_text(value: int) -> str:
    """Get a text description of satisfaction level"""
    if value >= 90:
        return "Excellent"
    elif value >= 75:
        return "Good"
    elif value >= 50:
        return "Neutral"
    elif value >= 25:
        return "Poor"
    else:
        return "Terrible"

def generate_random_event_message() -> str:
    """Generate a random event message for time passing"""
    messages = [
        "Time passes uneventfully...",
        "Another month goes by...",
        "Life continues as normal...",
        "Nothing extraordinary happens this month...",
        "The days blend together...",
        "You go about your daily routine...",
        "You take each day as it comes...",
        "Life has its ups and downs..."
    ]
    return random.choice(messages)

def get_milestone_message(age_years: int, age_months: int) -> str:
    """Get a milestone message based on age"""
    if age_years == 18 and age_months == 0:
        return "🎉 Congratulations! You're now a legal adult!"
    elif age_years == 21 and age_months == 0:
        return "🍹 You can now legally drink in the United States!"
    elif age_years == 30 and age_months == 0:
        return "🎂 Welcome to your 30s!"
    elif age_years == 40 and age_months == 0:
        return "🎂 Welcome to your 40s!"
    elif age_years == 44 and age_months == 0:
        return "⏳ Only one year of life left in the game!"
    return ""

def get_life_score(summary: Dict) -> int:
    """Calculate a life score based on the life summary"""
    score = 0
    
    # Money (max 30 points)
    net_worth = summary["net_worth"]
    if net_worth >= 1000000:
        score += 30
    elif net_worth >= 500000:
        score += 25
    elif net_worth >= 250000:
        score += 20
    elif net_worth >= 100000:
        score += 15
    elif net_worth >= 50000:
        score += 10
    elif net_worth >= 10000:
        score += 5
    
    # Career (max 20 points)
    if "CEO" in summary["career"] or "Director" in summary["career"]:
        score += 20
    elif "Manager" in summary["career"] or "Senior" in summary["career"]:
        score += 15
    elif summary["annual_income"] >= 50000:
        score += 10
    elif summary["annual_income"] >= 30000:
        score += 5
    
    # Relationships (max 20 points)
    good_relationships = 0
    for relationship in summary["relationships"].values():
        if relationship["satisfaction"] >= 75:
            good_relationships += 1
    
    if good_relationships >= 5:
        score += 20
    elif good_relationships >= 3:
        score += 15
    elif good_relationships >= 2:
        score += 10
    elif good_relationships >= 1:
        score += 5
    
    # Assets (max 15 points)
    asset_count = sum(summary["assets"].values())
    if asset_count >= 10:
        score += 15
    elif asset_count >= 7:
        score += 12
    elif asset_count >= 5:
        score += 10
    elif asset_count >= 3:
        score += 7
    elif asset_count >= 1:
        score += 5
    
    # Happiness and health (max 15 points)
    score += summary["happiness_score"]
    score += summary["health_score"] // 2
    
    return score

def get_life_grade(score: int) -> str:
    """Get a letter grade for the life score"""
    if score >= 90:
        return "A+"
    elif score >= 85:
        return "A"
    elif score >= 80:
        return "A-"
    elif score >= 75:
        return "B+"
    elif score >= 70:
        return "B"
    elif score >= 65:
        return "B-"
    elif score >= 60:
        return "C+"
    elif score >= 55:
        return "C"
    elif score >= 50:
        return "C-"
    elif score >= 45:
        return "D+"
    elif score >= 40:
        return "D"
    elif score >= 35:
        return "D-"
    else:
        return "F"