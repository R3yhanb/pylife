"""
Game logic for PyLife simulation
"""
import random
from typing import Dict, List, Optional, Tuple, Union

from models import Asset, Character, GameState, Job, Relationship
from events import (
    get_random_event, 
    get_random_initial_relationships, 
    get_career_options, 
    get_assets_for_sale
)

def create_character(name: str, gender: str) -> Character:
    """Create a new character with the given name and gender"""
    return Character(
        name=name,
        gender=gender,
        age_years=13,  # Start at age 13
        age_months=0
    )

def create_random_character() -> Character:
    """Create a random character"""
    male_names = ["James", "John", "Robert", "Michael", "William", "David", "Richard", "Joseph", "Thomas", "Charles"]
    female_names = ["Mary", "Patricia", "Jennifer", "Linda", "Elizabeth", "Barbara", "Susan", "Jessica", "Sarah", "Karen"]
    
    gender = random.choice(["Male", "Female"])
    name = random.choice(male_names if gender == "Male" else female_names)
    
    return Character(
        name=name,
        gender=gender
    )

def initialize_game_state(character: Character) -> GameState:
    """Initialize a new game state with the given character"""
    # Create initial relationships
    relationships_data = get_random_initial_relationships()
    relationships = {}
    for rel_id, rel_data in relationships_data.items():
        relationships[rel_id] = Relationship(
            name=rel_data["name"],
            relationship_type=rel_data["relationship_type"],
            satisfaction=rel_data["satisfaction"]
        )
    
    return GameState(
        character=character,
        relationships=relationships
    )

def apply_event_effects(game_state: GameState, effects: Dict, relationship_key: Optional[str] = None) -> str:
    """Apply event effects to game state and return a summary"""
    summary = []
    
    # Handle character stats
    for stat in ["health", "happiness", "intelligence", "appearance", "money"]:
        if stat in effects:
            old_value = getattr(game_state.character, stat)
            effect_value = effects[stat]
            
            # Handle lambda functions for randomized effects
            if callable(effect_value):
                effect_value = effect_value()
                
            new_value = max(0, old_value + effect_value)
            setattr(game_state.character, stat, new_value)
            
            if stat == "money":
                change = effect_value
                if change > 0:
                    summary.append(f"+${change} money")
                else:
                    summary.append(f"${change} money")
            else:
                change = effect_value
                if change > 0:
                    summary.append(f"+{change} {stat}")
                else:
                    summary.append(f"{change} {stat}")
    
    # Handle education updates
    if "education" in effects:
        old_education = game_state.character.education_level
        new_education = effects["education"]
        game_state.character.update_education(new_education)
        game_state.add_event(f"Education changed from {old_education} to {new_education}")
        summary.append(f"Advanced education to {new_education}")
    
    # Handle marriage events
    if "marry" in effects and effects["marry"]:
        # Generate random spouse name
        if game_state.character.gender == "Male":
            spouse_names = ["Mary", "Patricia", "Jennifer", "Linda", "Elizabeth", "Barbara", "Susan", "Jessica", "Sarah", "Karen"]
            spouse_name = random.choice(spouse_names)
        else:
            spouse_names = ["James", "John", "Robert", "Michael", "William", "David", "Richard", "Joseph", "Thomas", "Charles"]
            spouse_name = random.choice(spouse_names)
        
        game_state.character.marry(spouse_name)
        game_state.add_event(f"Got married to {spouse_name}")
        summary.append(f"Got married to {spouse_name}")
        
        # Add spouse as a relationship
        game_state.relationships["spouse"] = Relationship(
            name=spouse_name,
            relationship_type="spouse",
            satisfaction=random.randint(70, 90)
        )
    
    # Handle divorce events
    if "divorce" in effects and effects["divorce"] and game_state.character.is_married:
        ex_spouse = game_state.character.spouse_name
        game_state.character.divorce()
        game_state.add_event(f"Divorced from {ex_spouse}")
        summary.append(f"Divorced from {ex_spouse}")
        
        # Remove spouse from relationships or change relationship type
        if "spouse" in game_state.relationships:
            if random.random() < 0.3:  # 30% chance to remain friends
                game_state.relationships["ex_spouse"] = game_state.relationships["spouse"]
                game_state.relationships["ex_spouse"].relationship_type = "ex_spouse"
                game_state.relationships["ex_spouse"].satisfaction = random.randint(10, 40)
            del game_state.relationships["spouse"]
    
    # Handle children events
    if "add_child" in effects and effects["add_child"] and game_state.character.is_married:
        # Generate child name
        if random.random() < 0.5:  # 50% chance of boy or girl
            child_names = ["James Jr", "John Jr", "Robert Jr", "Michael Jr", "William Jr", "David Jr", "Joseph Jr"]
            child_gender = "Male"
        else:
            child_names = ["Mary Jr", "Patricia Jr", "Jennifer Jr", "Linda Jr", "Elizabeth Jr", "Sarah Jr", "Emma"]
            child_gender = "Female"
        
        child_name = random.choice(child_names)
        game_state.character.add_child(child_name)
        game_state.add_event(f"Had a child: {child_name}")
        summary.append(f"Had a {child_gender.lower()} child named {child_name}")
        
        # Add child as a relationship
        child_id = f"child_{len(game_state.character.children)}"
        game_state.relationships[child_id] = Relationship(
            name=child_name,
            relationship_type="child",
            satisfaction=random.randint(80, 100)
        )
    
    # Handle travel events
    if "visit_country" in effects and effects["visit_country"]:
        country = effects["visit_country"]
        
        # Handle lambda for random countries
        if callable(country):
            country = country()
            
        game_state.character.visit_country(country)
        game_state.add_event(f"Visited {country}")
        summary.append(f"Traveled to {country}")
    
    # Handle job effects
    if game_state.job:
        if "job_performance" in effects:
            old_performance = game_state.job.performance
            new_performance = max(0, min(100, old_performance + effects["job_performance"]))
            game_state.job.performance = new_performance
            
            change = effects["job_performance"]
            if change > 0:
                summary.append(f"+{change} job performance")
            else:
                summary.append(f"{change} job performance")
        
        if "promotion" in effects and effects["promotion"]:
            salary_increase = int(game_state.job.salary * 0.2)  # 20% raise
            game_state.job.salary += salary_increase
            game_state.job.title = f"Senior {game_state.job.title}"
            summary.append(f"Promoted to {game_state.job.title} (+${salary_increase}/yr)")
    
    # Handle relationship effects
    if relationship_key and relationship_key in game_state.relationships:
        relationship = game_state.relationships[relationship_key]
        
        for rel_effect in ["family_satisfaction", "friend_satisfaction", "spouse_satisfaction", "relationship_satisfaction"]:
            if rel_effect in effects:
                old_satisfaction = relationship.satisfaction
                new_satisfaction = max(0, min(100, old_satisfaction + effects[rel_effect]))
                relationship.satisfaction = new_satisfaction
                
                change = effects[rel_effect]
                if change > 0:
                    summary.append(f"+{change} relationship with {relationship.name}")
                else:
                    summary.append(f"{change} relationship with {relationship.name}")
    
    # Return formatted summary
    if not summary:
        return "No effect"
    
    return ", ".join(summary)

def get_available_jobs(game_state: GameState) -> List[Dict]:
    """Get list of available jobs based on character's intelligence"""
    intelligence = game_state.character.intelligence
    education = game_state.character.education_level
    
    # Get job options based on intelligence
    job_options = get_career_options(intelligence)
    
    # Filter by education requirements
    filtered_jobs = []
    for job in job_options:
        req_education = job.get("required_education", "None")
        
        # Check if education requirement is met
        if req_education == "None":
            filtered_jobs.append(job)
        elif req_education == "High School" and education != "None":
            filtered_jobs.append(job)
        elif req_education == "College Degree" and education in ["Bachelor's Degree", "Master's Degree", "PhD"]:
            filtered_jobs.append(job)
        elif req_education == "Master's Degree" and education in ["Master's Degree", "PhD"]:
            filtered_jobs.append(job)
        elif req_education == "Medical Degree" and education == "Medical Degree":
            filtered_jobs.append(job)
        elif req_education == "Law Degree" and education == "Law Degree":
            filtered_jobs.append(job)
    
    return filtered_jobs

def get_school_options() -> List[Dict]:
    """Get list of available schools"""
    return [
        {
            "name": "Community College",
            "description": "A two-year institution offering associate degrees and certificates.",
            "cost": 5000,
            "intelligence_gain": 10,
            "education_level": "Associate's Degree",
            "required_education": "High School",
            "required_age": 18
        },
        {
            "name": "University",
            "description": "A four-year institution offering bachelor's degrees in various fields.",
            "cost": 15000,
            "intelligence_gain": 15,
            "education_level": "Bachelor's Degree",
            "required_education": "High School",
            "required_age": 18
        },
        {
            "name": "Graduate School",
            "description": "Advanced education for those with a bachelor's degree.",
            "cost": 20000,
            "intelligence_gain": 20,
            "education_level": "Master's Degree",
            "required_education": "Bachelor's Degree",
            "required_age": 22
        },
        {
            "name": "Medical School",
            "description": "Specialized education for aspiring doctors.",
            "cost": 50000,
            "intelligence_gain": 25,
            "education_level": "Medical Degree",
            "required_education": "Bachelor's Degree",
            "required_age": 22
        },
        {
            "name": "Law School",
            "description": "Specialized education for aspiring lawyers.",
            "cost": 45000,
            "intelligence_gain": 20,
            "education_level": "Law Degree",
            "required_education": "Bachelor's Degree",
            "required_age": 22
        }
    ]

def enroll_in_school(game_state: GameState, school: Dict) -> bool:
    """Enroll in selected school"""
    character = game_state.character
    
    # Check requirements
    if character.age_years < school.get("required_age", 0):
        return False
    
    if character.education_level != school.get("required_education"):
        return False
    
    if character.money < school.get("cost", 0):
        return False
    
    # Enroll in school
    character.money -= school["cost"]
    character.intelligence += school["intelligence_gain"]
    character.update_education(school["education_level"])
    
    return True

def apply_for_job(game_state: GameState, job_data: Dict) -> bool:
    """Apply for a job and return whether application was successful"""
    character = game_state.character
    
    # Check if requirements are met
    if character.intelligence < job_data.get("required_intelligence", 0):
        return False
    
    # Check education requirement
    req_education = job_data.get("required_education", "None")
    if req_education != "None" and character.education_level != req_education:
        # Special cases for higher education
        if req_education == "College Degree" and character.education_level not in ["Bachelor's Degree", "Master's Degree", "PhD"]:
            return False
        elif req_education == "Master's Degree" and character.education_level not in ["Master's Degree", "PhD"]:
            return False
    
    # Chance of success based on intelligence relative to requirement
    intelligence_diff = character.intelligence - job_data.get("required_intelligence", 0)
    success_chance = 0.5 + (intelligence_diff / 100)  # Base 50% + adjustment for intelligence
    
    if random.random() < success_chance:
        # Got the job
        game_state.job = Job(
            title=job_data["title"],
            company=job_data["company"],
            salary=job_data["salary"]
        )
        return True
    
    return False

def quit_job(game_state: GameState) -> str:
    """Quit current job and return a message"""
    if not game_state.job:
        return "You don't have a job to quit."
    
    job_title = game_state.job.title
    company = game_state.job.company
    
    game_state.job = None
    
    return f"You quit your job as {job_title} at {company}."

def get_available_assets(game_state: GameState) -> Dict[str, List[Dict]]:
    """Get assets available for purchase"""
    # Get all available assets
    all_assets = get_assets_for_sale()
    
    # Filter based on character's money
    available_assets = {}
    for category, assets in all_assets.items():
        available_assets[category] = [
            asset for asset in assets 
            if asset["value"] <= game_state.character.money * 5  # Show assets up to 5x current money (for loans/financing)
        ]
    
    return available_assets

def purchase_asset(game_state: GameState, asset_data: Dict, category: str) -> bool:
    """Purchase an asset and return whether purchase was successful"""
    character = game_state.character
    
    # Check if player has enough money
    if character.money < asset_data["value"]:
        return False
    
    # Purchase the asset
    character.money -= asset_data["value"]
    
    # Add to assets
    game_state.assets.append(Asset(
        name=asset_data["name"],
        category=category,
        value=asset_data["value"]
    ))
    
    return True

def sell_asset(game_state: GameState, asset_index: int) -> int:
    """Sell an asset and return the sale amount"""
    if asset_index < 0 or asset_index >= len(game_state.assets):
        return 0
    
    asset = game_state.assets[asset_index]
    sale_value = int(asset.value * random.uniform(0.8, 1.2))  # Random sale value +/- 20%
    
    # Update character money
    game_state.character.money += sale_value
    
    # Remove asset
    game_state.assets.pop(asset_index)
    
    return sale_value

def interact_with_relationship(game_state: GameState, relationship_key: str, interaction_type: str) -> Union[int, Tuple[int, bool]]:
    """Interact with a relationship and return satisfaction change and romance success if applicable"""
    if relationship_key not in game_state.relationships:
        return 0
    
    relationship = game_state.relationships[relationship_key]
    
    # Process interaction
    change, romance_success = relationship.interact(interaction_type)
    
    # Add event to history
    interaction_descriptions = {
        "spend_time": f"Spent time with {relationship.name}",
        "give_gift": f"Gave a gift to {relationship.name}",
        "argue": f"Argued with {relationship.name}",
        "ignore": f"Ignored {relationship.name}",
        "flirt": f"Flirted with {relationship.name}"
    }
    
    event_text = interaction_descriptions.get(interaction_type, f"Interacted with {relationship.name}")
    if romance_success:
        event_text += f" (Relationship advanced to romantic!)"
    elif change > 0:
        event_text += f" (+{change} satisfaction)"
    elif change < 0:
        event_text += f" ({change} satisfaction)"
    
    game_state.add_event(event_text)
    
    if interaction_type == "flirt":
        return change, romance_success
    return change

def add_random_friend(game_state: GameState) -> Optional[str]:
    """Add a random friend and return their name"""
    # Generate random name based on character gender
    if game_state.character.gender == "Male":
        names = ["Thomas", "Nicholas", "Anthony", "Christopher", "Jonathan", "Steven", "Brian", "Kevin"]
    else:
        names = ["Emily", "Madison", "Ava", "Hannah", "Abigail", "Sarah", "Olivia", "Sophia"]
    
    # Filter out names already in relationships
    existing_names = {rel.name for rel in game_state.relationships.values()}
    available_names = [name for name in names if name not in existing_names]
    
    if not available_names:
        return None
    
    # Create a new friend
    friend_name = random.choice(available_names)
    friend_id = f"friend_{len(game_state.relationships) + 1}"
    
    game_state.relationships[friend_id] = Relationship(
        name=friend_name,
        relationship_type="friend",
        satisfaction=random.randint(50, 70)
    )
    
    return friend_name

def get_education_options(game_state: GameState) -> List[Dict]:
    """Get available education options based on current education level"""
    character = game_state.character
    
    # Get all school options
    all_options = get_school_options()
    
    # Filter based on current education level and age
    available_options = []
    for option in all_options:
        if (option["required_education"] == character.education_level and 
            character.age_years >= option["required_age"]):
            available_options.append(option)
    
    return available_options

def find_potential_spouse(game_state: GameState) -> Optional[Dict]:
    """Find a potential spouse for the character"""
    # Check for existing romantic relationships
    romantic_relationships = [
        (rel_id, rel) for rel_id, rel in game_state.relationships.items()
        if rel.relationship_type == "romantic" and rel.satisfaction >= 80
    ]
    
    if romantic_relationships:
        # Choose a random qualifying romantic relationship
        rel_id, relationship = random.choice(romantic_relationships)
        return {
            "id": rel_id,
            "name": relationship.name,
            "satisfaction": relationship.satisfaction
        }
    
    return None

def marry_character(game_state: GameState, spouse_data: Dict) -> str:
    """Marry character to specified spouse"""
    character = game_state.character
    
    if character.is_married:
        return f"You're already married to {character.spouse_name}."
    
    # Get spouse information
    spouse_id = spouse_data["id"]
    spouse_name = spouse_data["name"]
    
    # Update character
    character.marry(spouse_name)
    
    # Update relationship type
    if spouse_id in game_state.relationships:
        game_state.relationships[spouse_id].relationship_type = "spouse"
        # Create a new entry for spouse
        game_state.relationships["spouse"] = game_state.relationships[spouse_id]
        # Remove the old relationship
        del game_state.relationships[spouse_id]
    
    return f"Congratulations! You are now married to {spouse_name}."

def have_child(game_state: GameState) -> Optional[str]:
    """Have a child if character is married"""
    character = game_state.character
    
    if not character.is_married:
        return None
    
    # Age restrictions
    if character.age_years < 18 or character.age_years > 50:
        return None
    
    # Generate child name
    if random.random() < 0.5:  # 50% chance of boy or girl
        child_names = ["James Jr", "John Jr", "Robert Jr", "Michael Jr", "William Jr", "David Jr", "Joseph Jr"]
        child_gender = "Male"
    else:
        child_names = ["Mary Jr", "Patricia Jr", "Jennifer Jr", "Linda Jr", "Elizabeth Jr", "Sarah Jr", "Emma"]
        child_gender = "Female"
    
    # Avoid duplicate names
    for name in child_names:
        if name not in character.children:
            child_name = name
            break
    else:
        # If all names are used, add a number
        child_name = f"{random.choice(child_names)} {len(character.children) + 1}"
    
    # Add child to character
    character.add_child(child_name)
    
    # Add child as a relationship
    child_id = f"child_{len(character.children)}"
    game_state.relationships[child_id] = Relationship(
        name=child_name,
        relationship_type="child",
        satisfaction=random.randint(80, 100)
    )
    
    return child_name

def select_travel_destination(game_state: GameState) -> List[Dict]:
    """Get available travel destinations"""
    return [
        {
            "name": "Paris, France",
            "cost": 3000,
            "happiness_gain": 20,
            "country": "France"
        },
        {
            "name": "Tokyo, Japan",
            "cost": 4000,
            "happiness_gain": 25,
            "country": "Japan"
        },
        {
            "name": "Sydney, Australia",
            "cost": 5000,
            "happiness_gain": 30,
            "country": "Australia"
        },
        {
            "name": "Rome, Italy",
            "cost": 3500,
            "happiness_gain": 22,
            "country": "Italy"
        },
        {
            "name": "New York, USA",
            "cost": 2000,
            "happiness_gain": 15,
            "country": "USA"
        }
    ]

def travel_to_destination(game_state: GameState, destination: Dict) -> str:
    """Travel to the specified destination"""
    character = game_state.character
    
    # Check if enough money
    if character.money < destination["cost"]:
        return f"You don't have enough money to travel to {destination['name']}."
    
    # Update character
    character.money -= destination["cost"]
    character.happiness += destination["happiness_gain"]
    character.visit_country(destination["country"])
    
    # Add event
    game_state.add_event(f"Traveled to {destination['name']}")
    
    return f"You enjoyed your trip to {destination['name']}! (+{destination['happiness_gain']} happiness)"

def generate_life_summary(game_state: GameState) -> Dict:
    """Generate a summary of the player's life"""
    character = game_state.character
    
    # Calculate net worth (money + assets)
    assets_value = sum(asset.value for asset in game_state.assets)
    net_worth = character.money + assets_value
    
    # Get annual income from job
    annual_income = game_state.job.salary if game_state.job else 0
    
    # Count assets by category
    assets_by_category = {}
    for asset in game_state.assets:
        assets_by_category[asset.category] = assets_by_category.get(asset.category, 0) + 1
    
    # Relationships summary
    relationships_summary = {}
    for rel_id, relationship in game_state.relationships.items():
        relationships_summary[rel_id] = {
            "name": relationship.name,
            "type": relationship.relationship_type,
            "satisfaction": relationship.satisfaction
        }
    
    # Calculate life score components
    happiness_score = min(15, int(character.happiness / 10) + 5)
    health_score = min(15, int(character.health / 10) + 5)
    
    return {
        "name": character.name,
        "age": character.age_years,
        "net_worth": net_worth,
        "career": game_state.job.title if game_state.job else "Unemployed",
        "annual_income": annual_income,
        "assets": assets_by_category,
        "education": character.education_level,
        "children": len(character.children),
        "countries_visited": len(character.visited_countries),
        "relationships": relationships_summary,
        "happiness_score": happiness_score,
        "health_score": health_score
    }