"""
UI components for PyLife game
"""
import streamlit as st
import random
from datetime import datetime
from typing import Dict, List, Optional, Tuple, Union

from models import Character, GameState, Job, Asset, Relationship
from utils import (
    format_currency, 
    format_date, 
    get_progress_color, 
    get_satisfaction_text
)
from icons import (
    CROWN_ICON,
    HEALTH_ICON,
    HAPPINESS_ICON,
    MONEY_ICON,
    INTELLIGENCE_ICON,
    APPEARANCE_ICON,
    EDUCATION_ICON,
    CAREER_ICON,
    RELATIONSHIP_ICON,
    ASSET_ICON,
    RANDOM_EVENT_ICON,
    TRAVEL_ICON,
    MARRIAGE_ICON
)
from game_logic import (
    apply_for_job,
    quit_job,
    purchase_asset,
    enroll_in_school,
    get_available_jobs,
    get_school_options,
    get_available_assets,
    create_character,
    create_random_character,
    add_random_friend,
    interact_with_relationship,
    sell_asset
)
from styles import get_progress_bar_style, get_stat_style, get_event_card_style

def render_character_creation() -> Optional[Character]:
    """Render the character creation UI and return a character if created"""
    st.write("Create your character to begin your life journey.")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.subheader("Basic Information")
        name = st.text_input("Name", value="")
        gender = st.selectbox("Gender", ["Male", "Female"])
    
    with col2:
        st.subheader("Character Appearance")
        st.markdown(f"""
            <div style="border: 1px solid #4F5161; border-radius: 10px; padding: 10px; text-align: center; margin-bottom: 15px;">
                <div style="width: 100px; height: 100px; margin: 0 auto; background-color: #2E3546; border-radius: 50%; display: flex; align-items: center; justify-content: center;">
                    <span style="font-size: 40px;">{name[0].upper() if name else "?"}</span>
                </div>
                <p style="margin-top: 10px;">{name or "Your Character"}</p>
                <p style="margin-top: 5px; font-size: 0.9em; color: #ADB5BD;">{gender or "Select Gender"}</p>
            </div>
        """, unsafe_allow_html=True)
    
    st.write("---")
    st.subheader("Quick Start")
    
    col1, col2 = st.columns(2)
    
    with col1:
        if st.button("Create Custom Character"):
            if not name:
                st.error("Please enter a name for your character.")
                return None
            
            return create_character(name, gender)
    
    with col2:
        if st.button("Create Random Character"):
            return create_random_character()
    
    return None

def render_dashboard(game_state: GameState, event_history: List[str]):
    """Render the main dashboard UI"""
    character = game_state.character
    
    # Display character summary
    col1, col2, col3 = st.columns([2, 2, 3])
    
    with col1:
        # Basic info in a styled container
        st.markdown('<div class="character-summary">', unsafe_allow_html=True)
        st.markdown("### Basic Info")
        
        # Basic character info - use Streamlit native components
        st.write(f"**Name:** {character.name}")
        st.write(f"**Gender:** {character.gender}")
        st.write(f"**Age:** {character.get_age_string()}")
        st.write(f"**Birthday:** {character.get_birthday()}")
        
        # Marital status - use Streamlit native components
        marriage_status = f"Married to {character.spouse_name}" if character.is_married else "Single"
        st.markdown(f"""
            <div style="display: flex; align-items: center;">
                <div style="margin-right: 10px; width: 24px; height: 24px;">
                    {MARRIAGE_ICON}
                </div>
            </div>
        """, unsafe_allow_html=True)
        st.write(f"**Status:** {marriage_status}")
        
        # Education - use direct HTML instead of markdown
        # Education status display
        st.markdown(f"""
            <div style="display: flex; align-items: center;">
                <div style="margin-right: 10px; width: 24px; height: 24px;">
                    {EDUCATION_ICON}
                </div>
            </div>
        """, unsafe_allow_html=True)
        st.write(f"**Education:** {character.education_level}")
        st.markdown('</div>', unsafe_allow_html=True)

    with col2:
        # Financial and personal info in a styled container
        st.markdown('<div class="character-summary">', unsafe_allow_html=True)
        # Financial status
        st.markdown(f"""
            <div style="display: flex; align-items: center;">
                <div style="margin-right: 10px; width: 24px; height: 24px;">
                    {MONEY_ICON}
                </div>
            </div>
        """, unsafe_allow_html=True)
        st.write(f"**Money:** {format_currency(character.money)}")

        # Children
        if character.children:
            child_str = ", ".join(character.children)
            st.write(f"**Children:** {child_str}")

        # Countries visited
        if character.visited_countries:
            countries = ", ".join(list(character.visited_countries))
            st.markdown(f"""
                <div style="display: flex; align-items: center;">
                    <div style="margin-right: 10px; width: 24px; height: 24px;">
                        {TRAVEL_ICON}
                    </div>
                </div>
            """, unsafe_allow_html=True)
            st.write(f"**Traveled to:** {countries}")
        st.markdown('</div>', unsafe_allow_html=True)

    with col3:
        # Main stats with progress bars in a styled container
        st.markdown("### Stats")

        # Health
        health_color = get_stat_style(character.health)
        st.markdown(f"""
        <div style="display: flex; align-items: center; margin-bottom: 5px;">
            <div style="margin-right: 10px; width: 24px; height: 24px;">
                {HEALTH_ICON}
            </div>
        </div>
        """, unsafe_allow_html=True)
        st.write(f"**Health:** {character.health}%")
        st.progress(character.health/100.0)

        # Happiness
        happiness_color = get_stat_style(character.happiness)
        st.markdown(f"""
        <div style="display: flex; align-items: center; margin-bottom: 5px;">
            <div style="margin-right: 10px; width: 24px; height: 24px;">
                {HAPPINESS_ICON}
            </div>
        </div>
        """, unsafe_allow_html=True)
        st.write(f"**Happiness:** {character.happiness}%")
        st.progress(character.happiness/100.0)

        # Intelligence
        intelligence_color = get_stat_style(character.intelligence)
        st.markdown(f"""
        <div style="display: flex; align-items: center; margin-bottom: 5px;">
            <div style="margin-right: 10px; width: 24px; height: 24px;">
                {INTELLIGENCE_ICON}
            </div>
        </div>
        """, unsafe_allow_html=True)
        st.write(f"**Intelligence:** {character.intelligence}%")
        st.progress(character.intelligence/100.0)

        # Appearance
        appearance_color = get_stat_style(character.appearance)
        st.markdown(f"""
        <div style="display: flex; align-items: center; margin-bottom: 5px;">
            <div style="margin-right: 10px; width: 24px; height: 24px;">
                {APPEARANCE_ICON}
            </div>
        </div>
        """, unsafe_allow_html=True)
        st.write(f"**Appearance:** {character.appearance}%")
        st.progress(character.appearance/100.0)

    # Current job or school information
    st.markdown("### Current Status")
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown('<div class="character-summary">', unsafe_allow_html=True)
        if game_state.job:
            job = game_state.job
            st.markdown(f"""
                <div style="display: flex; align-items: center; margin-bottom: 10px;">
                    <div style="margin-right: 10px; width: 24px; height: 24px;">
                        {CAREER_ICON}
                    </div>
                </div>
            """, unsafe_allow_html=True)
            st.write(f"**Current Job:** {job.title} at {job.company}")
            st.write(f"**Salary:** {format_currency(job.salary)}/yr")
            st.write(f"**Performance:** {job.performance}%")
            st.write(f"**Years of Experience:** {job.years_experience:.1f}")
        else:
            st.markdown(f"""
                <div style="display: flex; align-items: center;">
                    <div style="margin-right: 10px; width: 24px; height: 24px;">
                        {CAREER_ICON}
                    </div>
                </div>
            """, unsafe_allow_html=True)
            st.write("**Career:** Unemployed")
            st.write("Visit the Career tab to find a job")
        st.markdown('</div>', unsafe_allow_html=True)
    
    with col2:
        st.markdown('<div class="character-summary">', unsafe_allow_html=True)
        if game_state.assets:
            st.markdown(f"""
                <div style="display: flex; align-items: center; margin-bottom: 10px;">
                    <div style="margin-right: 10px; width: 24px; height: 24px;">
                        {ASSET_ICON}
                    </div>
                </div>
            """, unsafe_allow_html=True)
            st.write(f"**Assets:** {len(game_state.assets)} items")
            
            for asset in game_state.assets[:3]:  # Show only top 3 assets
                st.write(f"**{asset.name}** ({asset.category})")
                st.write(f"Value: {format_currency(asset.value)}")
                st.write(f"Condition: {asset.condition}%")
                
            if len(game_state.assets) > 3:
                st.write(f"+{len(game_state.assets) - 3} more assets...")
        else:
            st.markdown(f"""
                <div style="display: flex; align-items: center;">
                    <div style="margin-right: 10px; width: 24px; height: 24px;">
                        {ASSET_ICON}
                    </div>
                </div>
            """, unsafe_allow_html=True)
            st.write("**Assets:** None")
            st.write("Visit the Assets tab to buy property")
        st.markdown('</div>', unsafe_allow_html=True)

    # Recent events
    st.markdown("### Recent Events")
    
    for event in event_history[-5:]:  # Show last 5 events
        # Determine if event is positive or negative for styling
        event_type = "normal"
        if any(positive in event.lower() for positive in ["increase", "improved", "aced", "won", "got", "success"]):
            event_type = "positive"
        elif any(negative in event.lower() for negative in ["decrease", "failed", "fired", "injured", "lost"]):
            event_type = "negative"
        
        # Display styled event based on type
        if event_type == "positive":
            st.success(event)
        elif event_type == "negative":
            st.error(event)
        else:
            st.info(event)

def render_education_tab(game_state: GameState):
    """Render the education tab UI"""
    character = game_state.character
    
    st.markdown("## Education")
    
    # Current education status
    st.markdown(f"""
        <div style="display: flex; align-items: center; margin-bottom: 15px;">
            <div style="margin-right: 10px; width: 24px; height: 24px;">
                {EDUCATION_ICON}
            </div>
        </div>
    """, unsafe_allow_html=True)
    st.write(f"**Current Education Level:** {character.education_level}")
    st.write(f"**Intelligence:** {character.intelligence}%")
    st.progress(character.intelligence/100.0)
    
    # Available education options
    st.markdown("### Education Options")
    
    # Check age requirements
    if character.age_years < 6:
        st.warning("You are too young for formal education. Wait until you're 6 years old.")
        return
    
    if character.education_level == "High School" and character.age_years < 18:
        st.info("You are currently attending high school.")
        return
    
    # Show available schools
    schools = get_school_options()
    
    for school in schools:
        col1, col2 = st.columns([3, 1])
        
        with col1:
            st.write(f"**{school['name']}**")
            st.write(f"{school['description']}")
            st.write(f"Cost: {format_currency(school['cost'])}")
            st.write(f"Intelligence Gain: +{school['intelligence_gain']}")
        
        with col2:
            if st.button(f"Enroll in {school['name']}", key=f"enroll_{school['name']}"):
                if character.money < school['cost']:
                    st.error(f"You don't have enough money to enroll in {school['name']}.")
                else:
                    success = enroll_in_school(game_state, school)
                    if success:
                        st.success(f"You have enrolled in {school['name']}!")
                        st.session_state.event_history.append(f"Enrolled in {school['name']}")
    
    # Study options if enrolled
    if character.education_level not in ["None", "High School"]:
        st.markdown("### Study Options")
        
        col1, col2 = st.columns(2)
        
        with col1:
            if st.button("Study Hard"):
                character.intelligence = min(100, character.intelligence + 5)
                character.happiness = max(0, character.happiness - 3)
                st.session_state.event_history.append("Studied hard (+5 intelligence, -3 happiness)")
                st.success("You studied hard and gained intelligence!")
        
        with col2:
            if st.button("Take a Break"):
                character.happiness = min(100, character.happiness + 5)
                st.session_state.event_history.append("Took a break from studying (+5 happiness)")
                st.info("You took a break and feel refreshed.")

def render_career_tab(game_state: GameState):
    """Render the career tab UI"""
    character = game_state.character
    
    st.markdown("## Career")
    
    # Current job status
    if game_state.job:
        job = game_state.job
        st.markdown(f"""
            <div style="display: flex; align-items: center; margin-bottom: 15px;">
                <div style="margin-right: 10px; width: 24px; height: 24px;">
                    {CAREER_ICON}
                </div>
            </div>
        """, unsafe_allow_html=True)
        
        st.write(f"**Current Job:** {job.title} at {job.company}")
        st.write(f"**Salary:** {format_currency(job.salary)}/yr")
        st.write(f"**Performance:** {job.performance}%")
        st.progress(job.performance/100.0)
        st.write(f"**Years of Experience:** {job.years_experience:.1f}")
        
        # Job actions
        col1, col2 = st.columns(2)
        with col1:
            if st.button("Work Hard"):
                change = job.work_hard()
                st.session_state.event_history.append(f"Worked hard at your job (+{change} performance)")
                st.success(f"You worked hard and improved your performance by {change}%!")
        
        with col2:
            if st.button("Slack Off"):
                change = job.slack_off()
                st.session_state.event_history.append(f"Slacked off at work ({change} performance)")
                st.warning(f"You slacked off at work and your performance decreased by {abs(change)}%.")
        
        # Quit job option
        if st.button("Quit Job"):
            message = quit_job(game_state)
            st.session_state.event_history.append(message)
            st.info(message)
            st.rerun()
    else:
        st.markdown(f"""
            <div style="display: flex; align-items: center;">
                <div style="margin-right: 10px; width: 24px; height: 24px;">
                    {CAREER_ICON}
                </div>
            </div>
        """, unsafe_allow_html=True)
        st.write("**Career Status:** Unemployed")
    
    # Job hunting section (only show if unemployed)
    if not game_state.job:
        st.markdown("### Available Jobs")
        
        # Get available jobs based on character's intelligence
        available_jobs = get_available_jobs(game_state)
        
        if not available_jobs:
            st.info("No jobs are currently available for your intelligence and education level.")
        else:
            for job in available_jobs:
                col1, col2 = st.columns([3, 1])
                
                with col1:
                    st.write(f"**{job['title']}** at {job['company']}")
                    st.write(f"Salary: {format_currency(job['salary'])}/yr")
                    st.write(f"Required Intelligence: {job['required_intelligence']}")
                    st.write(f"Required Education: {job['required_education']}")
                
                with col2:
                    if st.button(f"Apply for {job['title']}", key=f"apply_{job['title']}"):
                        success = apply_for_job(game_state, job)
                        if success:
                            st.success(f"You got the job as a {job['title']} at {job['company']}!")
                            st.session_state.event_history.append(f"Got a job as {job['title']} at {job['company']}")
                            st.rerun()
                        else:
                            st.error(f"Your application for {job['title']} was rejected.")
                            st.session_state.event_history.append(f"Application for {job['title']} was rejected")

def render_relationships_tab(game_state: GameState):
    """Render the relationships tab UI"""
    character = game_state.character
    
    st.markdown("## Relationships")
    
    # Relationship stats summary
    st.markdown(f"""
        <div style="display: flex; align-items: center; margin-bottom: 15px;">
            <div style="margin-right: 10px; width: 24px; height: 24px;">
                {RELATIONSHIP_ICON}
            </div>
        </div>
    """, unsafe_allow_html=True)
    st.write(f"**Total Relationships:** {len(game_state.relationships)}")
    
    # Marriage status
    marriage_status = f"Married to {character.spouse_name}" if character.is_married else "Single"
    st.markdown(f"""
        <div style="display: flex; align-items: center; margin-bottom: 10px;">
            <div style="margin-right: 10px; width: 24px; height: 24px;">
                {MARRIAGE_ICON}
            </div>
        </div>
    """, unsafe_allow_html=True)
    st.write(f"**Status:** {marriage_status}")
    
    # Children
    if character.children:
        child_str = ", ".join(character.children)
        st.write(f"**Children:** {child_str}")
    
    # Make a new friend
    if st.button("Meet New People"):
        new_friend = add_random_friend(game_state)
        if new_friend:
            st.success(f"You met and became friends with {new_friend}!")
            st.session_state.event_history.append(f"Made a new friend: {new_friend}")
            st.rerun()
        else:
            st.info("You couldn't find any new friends right now.")
    
    # Relationships list
    st.markdown("### Your Relationships")
    
    # Group relationships by type
    relationship_types = {
        "family": "Family",
        "friend": "Friends",
        "romantic": "Romantic Interests",
        "spouse": "Spouse",
        "ex_spouse": "Ex-Partners",
        "child": "Children"
    }
    
    for rel_type, label in relationship_types.items():
        # Filter relationships by type
        filtered_rels = {rel_id: rel for rel_id, rel in game_state.relationships.items() 
                         if rel.relationship_type == rel_type}
        
        if filtered_rels:
            st.markdown(f"#### {label}")
            
            for rel_id, relationship in filtered_rels.items():
                render_relationship_card(rel_id, relationship, game_state)

def render_relationship_card(rel_id: str, relationship: Relationship, game_state: GameState):
    """Render a single relationship card with interactions"""
    satisfaction_color = get_stat_style(relationship.satisfaction)
    satisfaction_text = get_satisfaction_text(relationship.satisfaction)
    
    # Use Streamlit's native components for the relationship card
    st.write(f"**{relationship.name}** ({relationship.relationship_type.capitalize()})")
    st.write(f"Satisfaction: {relationship.satisfaction}% ({satisfaction_text})")
    st.progress(relationship.satisfaction/100.0)
    
    # Interaction buttons
    col1, col2, col3 = st.columns(3)
    
    with col1:
        if st.button(f"Spend Time with {relationship.name}", key=f"spend_{rel_id}"):
            change = interact_with_relationship(game_state, rel_id, "spend_time")
            st.success(f"You spent time with {relationship.name}. Relationship improved by {change}%!")
    
    with col2:
        if st.button(f"Give Gift to {relationship.name}", key=f"gift_{rel_id}"):
            if game_state.character.money >= 100:
                game_state.character.money -= 100
                change = interact_with_relationship(game_state, rel_id, "give_gift")
                st.success(f"You gave a gift to {relationship.name}. Relationship improved by {change}%!")
            else:
                st.error("You don't have enough money for a gift (costs $100).")
    
    # Show flirt option for friends only
    if relationship.relationship_type == "friend":
        with col3:
            if st.button(f"Flirt with {relationship.name}", key=f"flirt_{rel_id}"):
                change, romance_success = interact_with_relationship(game_state, rel_id, "flirt")
                if romance_success:
                    st.success(f"You flirted with {relationship.name} and they reciprocated! You're now in a romantic relationship.")
                    st.rerun()  # Update the UI to show the new relationship type
                else:
                    if change > 0:
                        st.info(f"{relationship.name} appreciated the flirting, but just wants to be friends. Relationship improved by {change}%.")
                    else:
                        st.warning(f"{relationship.name} didn't appreciate the flirting. Relationship decreased by {abs(change)}%.")

def render_assets_tab(game_state: GameState):
    """Render the assets tab UI"""
    character = game_state.character
    
    st.markdown("## Assets")
    
    # Asset summary
    st.markdown(f"""
        <div style="display: flex; align-items: center; margin-bottom: 15px;">
            <div style="margin-right: 10px; width: 24px; height: 24px;">
                {ASSET_ICON}
            </div>
        </div>
    """, unsafe_allow_html=True)
    
    # Calculate net worth
    total_assets_value = sum(asset.value for asset in game_state.assets)
    net_worth = character.money + total_assets_value
    
    st.write(f"**Total Assets:** {len(game_state.assets)}")
    st.write(f"**Available Money:** {format_currency(character.money)}")
    st.write(f"**Net Worth:** {format_currency(net_worth)}")
    
    # Current assets
    if game_state.assets:
        st.markdown("### Your Assets")
        
        # Group assets by category
        asset_categories = {}
        for asset in game_state.assets:
            if asset.category not in asset_categories:
                asset_categories[asset.category] = []
            asset_categories[asset.category].append(asset)
        
        for category, assets in asset_categories.items():
            st.markdown(f"#### {category.capitalize()}")
            
            for i, asset in enumerate(assets):
                col1, col2 = st.columns([3, 1])
                
                with col1:
                    st.write(f"**{asset.name}**")
                    st.write(f"Value: {format_currency(asset.value)}")
                    st.write(f"Condition: {asset.condition}%")
                    st.progress(asset.condition/100.0)
                
                with col2:
                    if st.button(f"Sell {asset.name}", key=f"sell_{category}_{i}"):
                        sale_amount = sell_asset(game_state, i)
                        st.success(f"Sold {asset.name} for {format_currency(sale_amount)}!")
                        st.session_state.event_history.append(f"Sold {asset.name} for {format_currency(sale_amount)}")
                        st.rerun()
    
    # Buy new assets
    st.markdown("### Purchase Assets")
    
    # Get available assets
    available_assets = get_available_assets(game_state)
    
    # Select asset category
    categories = list(available_assets.keys())
    if not categories:
        st.info("No assets available for purchase with your current funds.")
        return
    
    selected_category = st.selectbox("Select category", categories)
    
    # Show assets in selected category
    if selected_category:
        st.markdown(f"#### Available {selected_category.capitalize()}")
        
        assets = available_assets[selected_category]
        
        if not assets:
            st.info(f"No {selected_category} available for purchase with your current funds.")
        else:
            for asset_data in assets:
                col1, col2 = st.columns([3, 1])
                
                with col1:
                    st.write(f"**{asset_data['name']}**")
                    st.write(f"{asset_data['description']}")
                    st.write(f"Price: {format_currency(asset_data['value'])}")
                
                with col2:
                    if st.button(f"Buy {asset_data['name']}", key=f"buy_{asset_data['name']}"):
                        if character.money < asset_data['value']:
                            st.error(f"You don't have enough money to buy {asset_data['name']}.")
                        else:
                            success = purchase_asset(game_state, asset_data, selected_category)
                            if success:
                                st.success(f"You purchased {asset_data['name']}!")
                                st.session_state.event_history.append(f"Purchased {asset_data['name']} for {format_currency(asset_data['value'])}")
                                st.rerun()
                            else:
                                st.error(f"Failed to purchase {asset_data['name']}.")

def render_events_tab(game_state: GameState):
    """Render the events tab UI"""
    character = game_state.character
    
    st.markdown("## Life Events")
    
    # Event history
    st.markdown("### Event History")
    
    # Display event history in reverse chronological order
    events = list(reversed(game_state.events_history[-20:]))  # Show last 20 events
    
    if not events:
        st.info("No life events yet.")
    else:
        for event in events:
            # Determine if event is positive or negative for styling
            event_type = "normal"
            if any(positive in event.lower() for positive in ["increase", "improved", "aced", "won", "got", "success"]):
                event_type = "positive"
            elif any(negative in event.lower() for negative in ["decrease", "failed", "fired", "injured", "lost"]):
                event_type = "negative"
            
            # Display event with appropriate styling based on type
            if event_type == "positive":
                st.success(event)
            elif event_type == "negative":
                st.error(event)
            else:
                st.info(event)

def render_life_summary(game_state: GameState):
    """Render the life summary screen at game end"""
    character = game_state.character
    
    # Generate summary
    summary = {
        "name": character.name,
        "age": character.age_years,
        "net_worth": character.money + sum(asset.value for asset in game_state.assets),
        "career": game_state.job.title if game_state.job else "Unemployed",
        "annual_income": game_state.job.salary if game_state.job else 0,
        "assets": {
            "houses": sum(1 for asset in game_state.assets if asset.category == "house"),
            "cars": sum(1 for asset in game_state.assets if asset.category == "car"),
            "electronics": sum(1 for asset in game_state.assets if asset.category == "electronics"),
            "investments": sum(1 for asset in game_state.assets if asset.category == "investment")
        },
        "education": character.education_level,
        "children": len(character.children),
        "countries_visited": len(character.visited_countries),
        "relationships": {
            rel_id: {
                "name": rel.name, 
                "type": rel.relationship_type, 
                "satisfaction": rel.satisfaction
            } for rel_id, rel in game_state.relationships.items()
        },
        "happiness_score": min(15, int(character.happiness / 10) + 5),
        "health_score": min(15, int(character.health / 10) + 5)
    }
    
    # Calculate final score
    from utils import get_life_score, get_life_grade
    final_score = get_life_score(summary)
    final_grade = get_life_grade(final_score)
    
    # Header
    st.title("Your Life Summary")
    
    # Basic information
    st.header(f"{character.name}'s Life")
    col1, col2 = st.columns([1, 1])
    with col1:
        st.subheader(f"Final Score: {final_score}")
    with col2:
        st.subheader(f"Grade: {final_grade}")
    
    # Key stats
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("### Personal")
        st.write(f"**Age:** {summary['age']} years")
        st.write(f"**Education:** {summary['education']}")
        st.write(f"**Health:** {character.health}%")
        st.write(f"**Happiness:** {character.happiness}%")
        st.write(f"**Marital Status:** {'Married' if character.is_married else 'Single'}")
        st.write(f"**Children:** {summary['children']}")
        st.write(f"**Countries Visited:** {summary['countries_visited']}")
    
    with col2:
        st.markdown("### Financial")
        st.write(f"**Career:** {summary['career']}")
        st.write(f"**Annual Income:** {format_currency(summary['annual_income'])}")
        st.write(f"**Net Worth:** {format_currency(summary['net_worth'])}")
        st.write(f"**Houses Owned:** {summary['assets']['houses']}")
        st.write(f"**Cars Owned:** {summary['assets']['cars']}")
        st.write(f"**Electronics Owned:** {summary['assets']['electronics']}")
        st.write(f"**Investments:** {summary['assets']['investments']}")
    
    # Relationships summary
    st.markdown("### Relationships")
    
    # Group relationships by type
    relationship_types = {
        "family": "Family",
        "friend": "Friends",
        "romantic": "Romantic Interests",
        "spouse": "Spouse",
        "ex_spouse": "Ex-Partners",
        "child": "Children"
    }
    
    for rel_type, label in relationship_types.items():
        # Count relationships of this type
        count = sum(1 for rel in summary['relationships'].values() if rel['type'] == rel_type)
        
        if count > 0:
            st.markdown(f"**{label}:** {count}")
    
    # Timeline (partial event history)
    st.markdown("### Life Timeline Highlights")
    timeline_events = game_state.events_history[:5] + random.sample(game_state.events_history[5:], min(10, len(game_state.events_history) - 5))
    timeline_events.sort(key=lambda x: int(x.split(":", 1)[0].split()[1]))  # Sort by age
    
    for event in timeline_events:
        st.markdown(f"- {event}")