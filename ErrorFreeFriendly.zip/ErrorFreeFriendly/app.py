"""
PyLife - A Life Simulation Game
Main application file
"""
import streamlit as st
import random
from datetime import datetime
import json

# Import modules
from audio import init_audio, toggle_music
from models import Character, GameState
from events import get_random_event
from game_logic import (
    create_character, 
    initialize_game_state, 
    apply_event_effects,
    generate_life_summary
)
from game_ui import (
    render_character_creation,
    render_dashboard,
    render_education_tab,
    render_career_tab,
    render_relationships_tab,
    render_assets_tab, 
    render_events_tab,
    render_life_summary
)
from save_manager import save_game, load_game, delete_save, get_all_saves
from utils import generate_random_event_message, get_milestone_message
from styles import get_css

# Set up page config
st.set_page_config(
    page_title="PyLife - A Life Simulation Game",
    page_icon="🌟",
    layout="wide",
    initial_sidebar_state="expanded"
)

def init_session_state():
    """Initialize session state variables"""
    if 'character' not in st.session_state:
        st.session_state.character = None
    
    if 'game_state' not in st.session_state:
        st.session_state.game_state = None
    
    if 'event_history' not in st.session_state:
        st.session_state.event_history = []
        
    if 'current_tab' not in st.session_state:
        st.session_state.current_tab = "Dashboard"
    
    if 'user_id' not in st.session_state:
        # For simplicity, use a default user ID
        st.session_state.user_id = "default_user"
    
    if 'game_over' not in st.session_state:
        st.session_state.game_over = False
    
    if 'saved_games' not in st.session_state:
        st.session_state.saved_games = {}

def add_custom_styling():
    """Add custom CSS"""
    # Apply custom CSS
    st.markdown(f"<style>{get_css()}</style>", unsafe_allow_html=True)

def start_new_game():
    """Start a new game by clearing the game state"""
    st.session_state.character = None
    st.session_state.game_state = None
    st.session_state.event_history = []
    st.session_state.current_tab = "Dashboard"
    st.session_state.game_over = False

def change_tab(tab_name):
    """Change the current tab"""
    st.session_state.current_tab = tab_name

def advance_time(months=1):
    """Advance time by the specified number of months"""
    game_state = st.session_state.game_state
    
    # Add "time passing" message
    random_message = generate_random_event_message()
    st.session_state.event_history.append(random_message)
    
    # Process random events
    event = get_random_event(game_state)
    if event:
        if "title" in event and "description" in event and "effects" in event:
            # Apply event effects
            effects_summary = apply_event_effects(game_state, event["effects"])
            
            # Add event to history
            game_state.add_event(f"{event['title']}: {event['description']} ({effects_summary})")
            st.session_state.event_history.append(f"{event['title']}: {event['description']} ({effects_summary})")
    
    # Advance time in game state
    is_birthday, game_over, old_date = game_state.advance_time(months)
    
    # Handle birthday
    if is_birthday:
        birthday_message = f"Happy Birthday! You are now {game_state.character.age_years} years old."
        game_state.add_event(birthday_message)
        st.session_state.event_history.append(birthday_message)
        
        # Check for age milestones
        milestone = get_milestone_message(game_state.character.age_years, game_state.character.age_months)
        if milestone:
            game_state.add_event(milestone)
            st.session_state.event_history.append(milestone)
    
    # Check for game over
    if game_over:
        st.session_state.game_over = True

def main():
    """Main application function"""
    # Initialize session state
    init_session_state()
    
    # Initialize audio system
    init_audio()
    
    # Add custom styling
    add_custom_styling()
    
    # Display sidebar
    with st.sidebar:
        st.image("generated-icon.png", width=100)
        st.title("PyLife")
        st.markdown("A life simulation game")
        
        # Game control buttons
        if st.session_state.game_state:
            if st.button("Save Game"):
                save_name = datetime.now().strftime("%Y-%m-%d %H:%M")
                success = save_game(st.session_state.user_id, save_name, st.session_state.game_state)
                if success:
                    st.success(f"Game saved as '{save_name}'")
                else:
                    st.error("Failed to save game")
            
            if st.button("Load Game"):
                st.session_state.show_load_screen = True
            
            if st.button("New Game"):
                start_new_game()
        
        # Advanced time button (only if game is active and not over)
        if st.session_state.game_state and not st.session_state.game_over:
            st.markdown("---")
            st.subheader("Time Control")
            
            col1, col2 = st.columns(2)
            with col1:
                if st.button("Advance 1 Month"):
                    advance_time(1)
            with col2:
                if st.button("Advance 1 Year"):
                    advance_time(12)
        
        # Navigation tabs (only if game is active)
        if st.session_state.game_state:
            st.markdown("---")
            st.subheader("Navigation")
            
            if st.button("Dashboard", key="nav_dashboard"):
                change_tab("Dashboard")
            if st.button("Education", key="nav_education"):
                change_tab("Education")
            if st.button("Career", key="nav_career"):
                change_tab("Career")
            if st.button("Relationships", key="nav_relationships"):
                change_tab("Relationships")
            if st.button("Assets", key="nav_assets"):
                change_tab("Assets")
            if st.button("Events", key="nav_events"):
                change_tab("Events")
    
    # Display load game screen if requested
    if st.session_state.get('show_load_screen', False):
        st.subheader("Load Game")
        
        # Get all saves for current user
        saves = get_all_saves(st.session_state.user_id)
        
        if not saves:
            st.info("No saved games found.")
            if st.button("Back"):
                st.session_state.show_load_screen = False
        else:
            # Display saves with load and delete buttons
            for save_name in saves:
                col1, col2, col3 = st.columns([3, 1, 1])
                
                with col1:
                    st.write(save_name)
                
                with col2:
                    if st.button("Load", key=f"load_{save_name}"):
                        game_state = load_game(st.session_state.user_id, save_name)
                        if game_state:
                            st.session_state.game_state = game_state
                            st.session_state.character = game_state.character
                            st.session_state.event_history = game_state.events_history
                            st.session_state.show_load_screen = False
                            st.rerun()
                        else:
                            st.error(f"Failed to load game '{save_name}'")
                
                with col3:
                    if st.button("Delete", key=f"delete_{save_name}"):
                        success = delete_save(st.session_state.user_id, save_name)
                        if success:
                            st.success(f"Deleted save '{save_name}'")
                            st.rerun()
                        else:
                            st.error(f"Failed to delete save '{save_name}'")
            
            if st.button("Back to Game"):
                st.session_state.show_load_screen = False
        
        # Exit early to avoid showing the main game screen
        return
    
    # Main content area
    # Character creation if no character exists
    if not st.session_state.character:
        st.title("PyLife - Create Your Character")
        
        character = render_character_creation()
        
        if character:
            st.session_state.character = character
            st.session_state.game_state = initialize_game_state(character)
            # Add initial event
            st.session_state.game_state.add_event("Born into the world")
            st.session_state.event_history.append("Game started! You were born into the world.")
            st.rerun()
    
    # Game over screen
    elif st.session_state.game_over:
        render_life_summary(st.session_state.game_state)
        
        if st.button("Start New Game"):
            start_new_game()
            st.rerun()
    
    # Main game interface
    else:
        # Display current tab
        if st.session_state.current_tab == "Dashboard":
            render_dashboard(st.session_state.game_state, st.session_state.event_history)
        
        elif st.session_state.current_tab == "Education":
            render_education_tab(st.session_state.game_state)
        
        elif st.session_state.current_tab == "Career":
            render_career_tab(st.session_state.game_state)
        
        elif st.session_state.current_tab == "Relationships":
            render_relationships_tab(st.session_state.game_state)
        
        elif st.session_state.current_tab == "Assets":
            render_assets_tab(st.session_state.game_state)
        
        elif st.session_state.current_tab == "Events":
            render_events_tab(st.session_state.game_state)

if __name__ == "__main__":
    main()