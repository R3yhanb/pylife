"""
Models for PyLife game
"""
import random
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple, Set


@dataclass
class Character:
    """Character class for the player"""
    name: str
    gender: str
    age_years: int = 18
    age_months: int = 0
    birth_month: int = field(default_factory=lambda: random.randint(1, 12))
    birth_day: int = field(default_factory=lambda: random.randint(1, 28))
    health: int = 100
    happiness: int = 50
    intelligence: int = field(default_factory=lambda: random.randint(50, 100))
    appearance: int = field(default_factory=lambda: random.randint(50, 100))
    money: int = 1000
    education_level: str = "High School"  # New field for education level
    is_married: bool = False  # New field for marital status
    spouse_name: Optional[str] = None  # New field for spouse name
    children: List[str] = field(default_factory=list)  # New field for children
    visited_countries: Set[str] = field(default_factory=set)  # New field for travel
    
    def get_birthday(self) -> str:
        """Returns formatted birthday string"""
        months = ["January", "February", "March", "April", "May", "June", 
                  "July", "August", "September", "October", "November", "December"]
        return f"{months[self.birth_month-1]} {self.birth_day}"
    
    def age_up(self, months: int = 1) -> Tuple[bool, bool]:
        """Age character by specified number of months
        Returns (is_birthday, game_over)"""
        is_birthday = False
        game_over = False
        
        for _ in range(months):
            self.age_months += 1
            if self.age_months >= 12:
                self.age_months = 0
                self.age_years += 1
                is_birthday = True
        
        # Check if game is over (player reached 85) - extended from 45
        if self.age_years >= 85:
            game_over = True
            
        return is_birthday, game_over
    
    def get_age_string(self) -> str:
        """Returns formatted age string"""
        return f"{self.age_years} years, {self.age_months} months"
        
    def marry(self, spouse_name: str) -> None:
        """Get married to a spouse"""
        self.is_married = True
        self.spouse_name = spouse_name
        
    def divorce(self) -> None:
        """Get divorced from spouse"""
        self.is_married = False
        self.spouse_name = None
        
    def add_child(self, child_name: str) -> None:
        """Add a child to the character"""
        self.children.append(child_name)
        
    def update_education(self, new_level: str) -> None:
        """Update education level"""
        self.education_level = new_level
        
    def visit_country(self, country: str) -> None:
        """Visit a new country"""
        self.visited_countries.add(country)


@dataclass
class Relationship:
    """Relationship class for family, friends, etc."""
    name: str
    relationship_type: str  # family, friend, romantic
    satisfaction: int = 50  # 0-100
    
    def interact(self, interaction_type: str) -> Tuple[int, bool]:
        """Process interaction and return (satisfaction change, romance success)"""
        change = 0
        romance_success = False
        
        if interaction_type == "spend_time":
            change = random.randint(5, 15)
        elif interaction_type == "give_gift":
            change = random.randint(10, 20)
        elif interaction_type == "argue":
            change = -random.randint(10, 25)
        elif interaction_type == "ignore":
            change = -random.randint(5, 15)
        elif interaction_type == "flirt" and self.relationship_type == "friend":
            change = random.randint(-10, 20)
            if self.satisfaction >= 70 and random.random() < 0.4:  # 40% chance if satisfaction is high
                self.relationship_type = "romantic"
                romance_success = True
                change = abs(change)  # Ensure positive change if successful
        
        self.satisfaction = max(0, min(100, self.satisfaction + change))
        return change, romance_success


@dataclass
class Job:
    """Job class for careers"""
    title: str
    company: str
    salary: int
    performance: int = 50  # 0-100
    years_experience: int = 0
    
    def work_hard(self) -> int:
        """Work hard at job and return performance change"""
        change = random.randint(5, 15)
        self.performance = min(100, self.performance + change)
        return change
    
    def slack_off(self) -> int:
        """Slack off at job and return performance change"""
        change = -random.randint(5, 15)
        self.performance = max(0, self.performance + change)
        return change
    
    def get_salary_increase(self) -> int:
        """Calculate salary increase based on performance"""
        if self.performance >= 80:
            return int(self.salary * 0.1)  # 10% raise
        elif self.performance >= 60:
            return int(self.salary * 0.05)  # 5% raise
        return 0


@dataclass
class Asset:
    """Asset class for purchases"""
    name: str
    category: str  # house, car, electronics, antique
    value: int
    condition: int = 100  # 0-100
    
    def depreciate(self) -> int:
        """Depreciate asset value and return depreciation amount"""
        depreciation_rate = 0
        if self.category == "car":
            depreciation_rate = 0.1  # 10% depreciation per year
        elif self.category == "electronics":
            depreciation_rate = 0.2  # 20% depreciation per year
        elif self.category == "house":
            depreciation_rate = 0.03  # 3% depreciation per year
        elif self.category == "antique":
            depreciation_rate = -0.05  # 5% appreciation per year (negative depreciation)
        
        old_value = self.value
        self.value = int(self.value * (1 - depreciation_rate))
        self.condition = max(0, self.condition - random.randint(0, 10))
        
        return old_value - self.value


@dataclass
class GameState:
    """Class to store the entire game state"""
    character: Character
    relationships: Dict[str, Relationship] = field(default_factory=dict)
    job: Optional[Job] = None
    assets: List[Asset] = field(default_factory=list)
    current_date: datetime = field(default_factory=lambda: datetime(2023, 1, 1))
    events_history: List[str] = field(default_factory=list)
    
    def add_event(self, event: str):
        """Add event to history"""
        self.events_history.append(f"Age {self.character.get_age_string()}: {event}")
    
    def advance_time(self, months: int = 1) -> Tuple[bool, bool, datetime]:
        """Advance time by specified number of months
        Returns (is_birthday, game_over, new_date)"""
        old_date = self.current_date
        
        # Age up character
        is_birthday, game_over = self.character.age_up(months)
        
        # Update current date
        new_month = self.current_date.month + months
        new_year = self.current_date.year + (new_month - 1) // 12
        new_month = ((new_month - 1) % 12) + 1
        
        try:
            self.current_date = self.current_date.replace(year=new_year, month=new_month)
        except ValueError:
            # Handle edge cases like February 29
            if new_month == 2:
                self.current_date = self.current_date.replace(year=new_year, month=new_month, day=28)
            else:
                last_day = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31][new_month-1]
                self.current_date = self.current_date.replace(year=new_year, month=new_month, day=last_day)
        
        # Update salary if employed
        if self.job:
            self.character.money += self.job.salary
            self.job.years_experience += months / 12
        
        # Random health decrease
        if random.random() < 0.3:  # 30% chance
            health_change = -random.randint(1, 5)
            self.character.health = max(0, self.character.health + health_change)
            
        # Random happiness change
        if random.random() < 0.5:  # 50% chance
            happiness_change = random.randint(-5, 5)
            self.character.happiness = max(0, min(100, self.character.happiness + happiness_change))
        
        # Depreciate assets
        for asset in self.assets:
            asset.depreciate()
            
        return is_birthday, game_over, old_date