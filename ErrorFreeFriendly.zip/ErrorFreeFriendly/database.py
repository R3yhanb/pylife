"""
Database module for PyLife game
"""
import os
import json
from datetime import datetime
from typing import Dict, List, Optional

from sqlalchemy import create_engine, Column, Integer, String, DateTime, Boolean, Text, ForeignKey
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship, sessionmaker

# Get database URL from environment
DATABASE_URL = os.environ.get("DATABASE_URL")

# Create engine and session
engine = create_engine(DATABASE_URL)
Session = sessionmaker(bind=engine)
Base = declarative_base()

class User(Base):
    __tablename__ = "users"
    
    id = Column(Integer, primary_key=True)
    username = Column(String(50), unique=True, nullable=False)
    password_hash = Column(String(100), nullable=False)
    email = Column(String(100), unique=True, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    
    games = relationship("GameSave", back_populates="user", cascade="all, delete-orphan")
    
    def __repr__(self):
        return f"<User(username='{self.username}')>"

class GameSave(Base):
    __tablename__ = "game_saves"
    
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    save_name = Column(String(100), nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)
    last_updated = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Character data
    character_name = Column(String(100), nullable=False)
    character_gender = Column(String(20), nullable=False)
    character_age_years = Column(Integer, default=18)
    character_age_months = Column(Integer, default=0)
    character_birth_month = Column(Integer)
    character_birth_day = Column(Integer)
    character_health = Column(Integer, default=100)
    character_happiness = Column(Integer, default=50)
    character_intelligence = Column(Integer)
    character_appearance = Column(Integer)
    character_money = Column(Integer, default=1000)
    character_education = Column(String(50), default="High School")
    character_is_married = Column(Boolean, default=False)
    character_spouse_name = Column(String(100), nullable=True)
    character_children = Column(Text, default="[]")  # JSON serialized array
    character_visited_countries = Column(Text, default="[]")  # JSON serialized array
    
    # Game state data
    current_date = Column(DateTime)
    relationships_data = Column(Text)  # JSON serialized
    job_data = Column(Text)  # JSON serialized
    assets_data = Column(Text)  # JSON serialized
    events_history = Column(Text)  # JSON serialized
    month_history = Column(Text)  # JSON serialized
    
    # Relationship to user
    user = relationship("User", back_populates="games")
    
    def __repr__(self):
        return f"<GameSave(character_name='{self.character_name}', save_name='{self.save_name}')>"
    
    def to_game_state(self):
        """Convert database record to a GameState object"""
        from models import Character, GameState, Relationship, Job, Asset
        
        # Create character
        character = Character(
            name=self.character_name,
            gender=self.character_gender,
            age_years=self.character_age_years,
            age_months=self.character_age_months,
            birth_month=self.character_birth_month,
            birth_day=self.character_birth_day,
            health=self.character_health,
            happiness=self.character_happiness,
            intelligence=self.character_intelligence,
            appearance=self.character_appearance,
            money=self.character_money,
            education_level=self.character_education,
            is_married=self.character_is_married,
            spouse_name=self.character_spouse_name
        )
        
        # Load children
        children = json.loads(self.character_children)
        character.children = children
        
        # Load visited countries
        visited_countries = json.loads(self.character_visited_countries)
        character.visited_countries = set(visited_countries)
        
        # Create GameState
        game_state = GameState(character=character)
        
        # Set current date
        game_state.current_date = self.current_date
        
        # Load relationships
        if self.relationships_data:
            relationships_data = json.loads(self.relationships_data)
            for rel_id, rel_data in relationships_data.items():
                game_state.relationships[rel_id] = Relationship(
                    name=rel_data["name"],
                    relationship_type=rel_data["relationship_type"],
                    satisfaction=rel_data["satisfaction"]
                )
        
        # Load job
        if self.job_data:
            job_data = json.loads(self.job_data)
            if job_data:
                game_state.job = Job(
                    title=job_data["title"],
                    company=job_data["company"],
                    salary=job_data["salary"],
                    performance=job_data["performance"],
                    years_experience=job_data["years_experience"]
                )
        
        # Load assets
        if self.assets_data:
            assets_data = json.loads(self.assets_data)
            for asset_data in assets_data:
                game_state.assets.append(Asset(
                    name=asset_data["name"],
                    category=asset_data["category"],
                    value=asset_data["value"],
                    condition=asset_data["condition"]
                ))
        
        # Load events history
        if self.events_history:
            game_state.events_history = json.loads(self.events_history)
        
        return game_state
    
    @classmethod
    def from_game_state(cls, game_state, user_id, save_name=None):
        """Create a GameSave instance from a GameState object"""
        character = game_state.character
        
        # Create GameSave instance
        game_save = cls(
            user_id=user_id,
            save_name=save_name or f"{character.name}'s Life - {datetime.now().strftime('%Y-%m-%d %H:%M')}",
            character_name=character.name,
            character_gender=character.gender,
            character_age_years=character.age_years,
            character_age_months=character.age_months,
            character_birth_month=character.birth_month,
            character_birth_day=character.birth_day,
            character_health=character.health,
            character_happiness=character.happiness,
            character_intelligence=character.intelligence,
            character_appearance=character.appearance,
            character_money=character.money,
            character_education=character.education_level,
            character_is_married=character.is_married,
            character_spouse_name=character.spouse_name,
            character_children=json.dumps(character.children),
            character_visited_countries=json.dumps(list(character.visited_countries)),
            current_date=game_state.current_date
        )
        
        # Save relationships
        relationships_data = {}
        for rel_id, relationship in game_state.relationships.items():
            relationships_data[rel_id] = {
                "name": relationship.name,
                "relationship_type": relationship.relationship_type,
                "satisfaction": relationship.satisfaction
            }
        game_save.relationships_data = json.dumps(relationships_data)
        
        # Save job
        if game_state.job:
            job_data = {
                "title": game_state.job.title,
                "company": game_state.job.company,
                "salary": game_state.job.salary,
                "performance": game_state.job.performance,
                "years_experience": game_state.job.years_experience
            }
            game_save.job_data = json.dumps(job_data)
        else:
            game_save.job_data = json.dumps(None)
        
        # Save assets
        assets_data = []
        for asset in game_state.assets:
            assets_data.append({
                "name": asset.name,
                "category": asset.category,
                "value": asset.value,
                "condition": asset.condition
            })
        game_save.assets_data = json.dumps(assets_data)
        
        # Save events history
        game_save.events_history = json.dumps(game_state.events_history)
        
        return game_save

def init_db():
    """Initialize the database by creating all tables"""
    Base.metadata.create_all(engine)

def create_user(username: str, password_hash: str, email: Optional[str] = None) -> User:
    """Create a new user and return the User object"""
    session = Session()
    try:
        user = User(username=username, password_hash=password_hash, email=email)
        session.add(user)
        session.commit()
        return user
    except Exception as e:
        session.rollback()
        raise e
    finally:
        session.close()

def get_user_by_username(username: str) -> Optional[User]:
    """Get a user by username, or None if not found"""
    session = Session()
    try:
        user = session.query(User).filter_by(username=username).first()
        return user
    finally:
        session.close()

def save_game(game_state, user_id: int, save_name: Optional[str] = None) -> int:
    """Save a game state to the database and return the save ID"""
    session = Session()
    try:
        game_save = GameSave.from_game_state(game_state, user_id, save_name)
        session.add(game_save)
        session.commit()
        return game_save.id
    except Exception as e:
        session.rollback()
        raise e
    finally:
        session.close()

def load_game(save_id: int) -> Optional[GameSave]:
    """Load a game save by ID, or None if not found"""
    session = Session()
    try:
        game_save = session.query(GameSave).filter_by(id=save_id).first()
        return game_save
    finally:
        session.close()

def get_user_saves(user_id: int) -> List[Dict]:
    """Get a list of all saves for a user"""
    session = Session()
    try:
        saves = session.query(GameSave).filter_by(user_id=user_id).all()
        return [
            {
                "id": save.id,
                "save_name": save.save_name,
                "character_name": save.character_name,
                "character_age": f"{save.character_age_years} years, {save.character_age_months} months",
                "last_updated": save.last_updated.strftime("%Y-%m-%d %H:%M")
            }
            for save in saves
        ]
    finally:
        session.close()

def delete_save(save_id: int) -> bool:
    """Delete a save by ID, return True if successful"""
    session = Session()
    try:
        game_save = session.query(GameSave).filter_by(id=save_id).first()
        if game_save:
            session.delete(game_save)
            session.commit()
            return True
        return False
    except Exception as e:
        session.rollback()
        return False
    finally:
        session.close()

# Initialize database
init_db()