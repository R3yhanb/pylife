"""
Events system for PyLife
"""
import random
from typing import Dict, List, Optional

def get_random_initial_relationships() -> Dict:
    """Generate random initial relationships for a new character"""
    # Generate random parents
    father_names = ["James", "John", "Robert", "Michael", "William", "David", "Richard", "Joseph"]
    mother_names = ["Mary", "Patricia", "Jennifer", "Linda", "Elizabeth", "Barbara", "Susan", "Jessica"]
    
    relationships = {
        "father": {
            "name": random.choice(father_names),
            "relationship_type": "family",
            "satisfaction": random.randint(50, 90)
        },
        "mother": {
            "name": random.choice(mother_names),
            "relationship_type": "family",
            "satisfaction": random.randint(50, 90)
        }
    }
    
    # Generate random siblings (0-2)
    num_siblings = random.randint(0, 2)
    for i in range(num_siblings):
        gender = random.choice(["Male", "Female"])
        if gender == "Male":
            name = random.choice(["Jack", "Daniel", "Andrew", "Matthew", "Kevin", "Brian"])
        else:
            name = random.choice(["Emma", "Olivia", "Sophia", "Isabella", "Mia", "Charlotte"])
        
        relationships[f"sibling_{i+1}"] = {
            "name": name,
            "relationship_type": "family",
            "satisfaction": random.randint(40, 90)
        }
    
    # Generate random friends (1-3)
    num_friends = random.randint(1, 3)
    friend_names_male = ["Thomas", "Nicholas", "Anthony", "Christopher", "Jonathan", "Steven"]
    friend_names_female = ["Emily", "Madison", "Ava", "Hannah", "Abigail", "Sarah"]
    
    for i in range(num_friends):
        gender = random.choice(["Male", "Female"])
        if gender == "Male":
            name = random.choice(friend_names_male)
            friend_names_male.remove(name)  # Prevent duplicates
        else:
            name = random.choice(friend_names_female)
            friend_names_female.remove(name)  # Prevent duplicates
        
        relationships[f"friend_{i+1}"] = {
            "name": name,
            "relationship_type": "friend",
            "satisfaction": random.randint(60, 90)
        }
    
    return relationships

# Education events
EDUCATION_EVENTS = [
    {
        "title": "Study Hard",
        "description": "You spent the month studying diligently.",
        "requires": {"min_age": 6, "max_age": 22},
        "effects": {"intelligence": 5, "happiness": -2}
    },
    {
        "title": "Skip Class",
        "description": "You decided to skip classes this month.",
        "requires": {"min_age": 6, "max_age": 22},
        "effects": {"intelligence": -3, "happiness": 3}
    },
    {
        "title": "Failed Exam",
        "description": "You failed an important exam.",
        "requires": {"min_age": 6, "max_age": 22},
        "effects": {"intelligence": -1, "happiness": -5}
    },
    {
        "title": "Aced Exam",
        "description": "You aced an important exam!",
        "requires": {"min_age": 6, "max_age": 22, "min_intelligence": 60},
        "effects": {"intelligence": 3, "happiness": 10}
    },
    {
        "title": "Graduation",
        "description": "You graduated with honors!",
        "requires": {"min_age": 18, "max_age": 25, "min_intelligence": 70},
        "effects": {"education": "College Degree", "happiness": 15}
    }
]

# Marriage events
MARRIAGE_EVENTS = [
    {
        "title": "Marriage Proposal",
        "description": "You were proposed to!",
        "requires": {"min_age": 18, "not_married": True, "chance": 0.5},
        "effects": {"marry": True, "happiness": 20}
    },
    {
        "title": "Marriage Problems",
        "description": "Your marriage is going through a rough patch.",
        "requires": {"is_married": True, "chance": 0.3},
        "effects": {"happiness": -10, "spouse_satisfaction": -15}
    },
    {
        "title": "Marriage Counseling",
        "description": "You attended marriage counseling.",
        "requires": {"is_married": True, "chance": 0.2},
        "effects": {"happiness": 5, "spouse_satisfaction": 10, "money": -500}
    },
    {
        "title": "Divorce",
        "description": "Your marriage has ended in divorce.",
        "requires": {"is_married": True, "chance": 0.1},
        "effects": {"divorce": True, "happiness": -20, "money": -5000}
    },
    {
        "title": "Anniversary",
        "description": "You celebrated your wedding anniversary.",
        "requires": {"is_married": True, "chance": 0.4},
        "effects": {"happiness": 10, "spouse_satisfaction": 15, "money": -200}
    }
]

# Children events
CHILDREN_EVENTS = [
    {
        "title": "Pregnancy",
        "description": "You're expecting a child!",
        "requires": {"is_married": True, "min_age": 20, "max_age": 45, "chance": 0.4},
        "effects": {"add_child": True, "happiness": 15, "health": -5, "money": -1000}
    },
    {
        "title": "Child's Birthday",
        "description": "You celebrated your child's birthday.",
        "requires": {"has_children": True, "chance": 0.5},
        "effects": {"happiness": 10, "money": -200}
    },
    {
        "title": "Child's School Problem",
        "description": "Your child got in trouble at school.",
        "requires": {"has_children": True, "chance": 0.3},
        "effects": {"happiness": -10}
    },
    {
        "title": "Child's Achievement",
        "description": "Your child won an award at school!",
        "requires": {"has_children": True, "chance": 0.3},
        "effects": {"happiness": 15}
    }
]

# Travel events
TRAVEL_EVENTS = [
    {
        "title": "Vacation",
        "description": "You took a relaxing vacation.",
        "requires": {"min_age": 18, "min_money": 2000},
        "effects": {"happiness": 20, "health": 5, "money": -2000, "visit_country": "Italy"}
    },
    {
        "title": "Business Trip",
        "description": "You went on a business trip.",
        "requires": {"min_age": 22, "has_job": True},
        "effects": {"job_performance": 10, "happiness": -5, "visit_country": "Japan"}
    },
    {
        "title": "Backpacking",
        "description": "You went backpacking across Europe.",
        "requires": {"min_age": 18, "max_age": 30, "min_money": 3000},
        "effects": {"happiness": 15, "health": -5, "money": -3000, "visit_country": "France"}
    },
    {
        "title": "Cruise",
        "description": "You went on a luxury cruise.",
        "requires": {"min_age": 25, "min_money": 5000},
        "effects": {"happiness": 25, "health": 10, "money": -5000, "visit_country": "Bahamas"}
    }
]

# Disaster events
DISASTER_EVENTS = [
    {
        "title": "House Fire",
        "description": "Your house caught fire!",
        "requires": {"owns_house": True, "chance": 0.1},
        "effects": {"happiness": -20, "house_value": -10000}
    },
    {
        "title": "Car Accident",
        "description": "You were in a car accident.",
        "requires": {"owns_car": True, "chance": 0.2},
        "effects": {"health": -20, "happiness": -15, "car_condition": -50, "money": -2000}
    },
    {
        "title": "Natural Disaster",
        "description": "A natural disaster damaged your property.",
        "requires": {"owns_asset": True, "chance": 0.05},
        "effects": {"happiness": -15, "assets_condition": -30, "money": -3000}
    },
    {
        "title": "Robbery",
        "description": "Your home was broken into.",
        "requires": {"min_age": 18, "chance": 0.1},
        "effects": {"happiness": -15, "money": -1000}
    }
]

# Lottery events
LOTTERY_EVENTS = [
    {
        "title": "Lottery Win (Small)",
        "description": "You won a small lottery prize!",
        "requires": {"min_age": 18, "chance": 0.1},
        "effects": {"happiness": 10, "money": 1000}
    },
    {
        "title": "Lottery Win (Medium)",
        "description": "You won a significant lottery prize!",
        "requires": {"min_age": 18, "chance": 0.01},
        "effects": {"happiness": 30, "money": 10000}
    },
    {
        "title": "Lottery Win (Large)",
        "description": "You won a major lottery jackpot!",
        "requires": {"min_age": 18, "chance": 0.001},
        "effects": {"happiness": 50, "money": 100000}
    }
]

def get_random_event(game_state) -> Optional[Dict]:
    """Get a random event based on character status"""
    all_events = []
    
    # Education events
    if (game_state.character.age_years >= 6 and 
        game_state.character.age_years <= 22):
        all_events.extend(EDUCATION_EVENTS)
    
    # Marriage events
    if game_state.character.age_years >= 18:
        for event in MARRIAGE_EVENTS:
            requires = event.get("requires", {})
            
            # Check marriage status
            if requires.get("is_married", False) and not game_state.character.is_married:
                continue
            if requires.get("not_married", False) and game_state.character.is_married:
                continue
                
            all_events.append(event)
    
    # Children events
    if game_state.character.is_married and game_state.character.age_years >= 20:
        for event in CHILDREN_EVENTS:
            requires = event.get("requires", {})
            
            # Check if has children
            if requires.get("has_children", False) and not game_state.character.children:
                continue
                
            all_events.append(event)
    
    # Travel events
    if game_state.character.age_years >= 18:
        for event in TRAVEL_EVENTS:
            requires = event.get("requires", {})
            
            # Check money requirements
            if "min_money" in requires and game_state.character.money < requires["min_money"]:
                continue
                
            # Check job requirement
            if requires.get("has_job", False) and not game_state.job:
                continue
                
            all_events.append(event)
    
    # Disaster events
    for event in DISASTER_EVENTS:
        requires = event.get("requires", {})
        
        # Check asset ownership
        if requires.get("owns_house", False):
            has_house = any(asset.category == "house" for asset in game_state.assets)
            if not has_house:
                continue
        
        if requires.get("owns_car", False):
            has_car = any(asset.category == "car" for asset in game_state.assets)
            if not has_car:
                continue
                
        if requires.get("owns_asset", False) and not game_state.assets:
            continue
            
        all_events.append(event)
    
    # Lottery events (always possible for adults)
    if game_state.character.age_years >= 18:
        all_events.extend(LOTTERY_EVENTS)
    
    # If no events are applicable, return None
    if not all_events:
        return None
    
    # Select random event
    selected_event = random.choice(all_events)
    
    # Check chance
    chance = selected_event.get("requires", {}).get("chance", 1.0)
    if random.random() > chance:
        return None
    
    return selected_event

def get_career_options(intelligence: int) -> List[Dict]:
    """Get available career options based on intelligence"""
    all_careers = [
        {
            "title": "Fast Food Worker",
            "company": "Burger Palace",
            "required_intelligence": 30,
            "required_education": "None",
            "salary": 15000
        },
        {
            "title": "Retail Clerk",
            "company": "ShopMart",
            "required_intelligence": 40,
            "required_education": "None",
            "salary": 18000
        },
        {
            "title": "Office Assistant",
            "company": "Corporate Inc.",
            "required_intelligence": 50,
            "required_education": "High School",
            "salary": 25000
        },
        {
            "title": "Sales Representative",
            "company": "SellCo",
            "required_intelligence": 60,
            "required_education": "High School",
            "salary": 35000
        },
        {
            "title": "Teacher",
            "company": "Public School",
            "required_intelligence": 70,
            "required_education": "College Degree",
            "salary": 45000
        },
        {
            "title": "Software Developer",
            "company": "Tech Innovations",
            "required_intelligence": 80,
            "required_education": "College Degree",
            "salary": 70000
        },
        {
            "title": "Doctor",
            "company": "City Hospital",
            "required_intelligence": 90,
            "required_education": "Medical Degree",
            "salary": 120000
        },
        {
            "title": "Lawyer",
            "company": "Law Firm",
            "required_intelligence": 85,
            "required_education": "Law Degree",
            "salary": 100000
        }
    ]
    
    # Filter by intelligence
    available_careers = [career for career in all_careers 
                         if career["required_intelligence"] <= intelligence]
    
    # Randomize a subset of available careers (2-4)
    num_options = min(len(available_careers), random.randint(2, 4))
    return random.sample(available_careers, num_options)

def get_assets_for_sale() -> Dict[str, List[Dict]]:
    """Get assets available for purchase"""
    return {
        "houses": [
            {
                "name": "Small Apartment",
                "category": "house",
                "value": 80000,
                "description": "A cozy one-bedroom apartment in an okay neighborhood."
            },
            {
                "name": "Townhouse",
                "category": "house",
                "value": 200000,
                "description": "A decent-sized townhouse with 2 bedrooms."
            },
            {
                "name": "Suburban Home",
                "category": "house",
                "value": 350000,
                "description": "A comfortable 3-bedroom house in the suburbs."
            },
            {
                "name": "Luxury Condo",
                "category": "house",
                "value": 500000,
                "description": "A high-end condo in a prime location."
            }
        ],
        "cars": [
            {
                "name": "Used Sedan",
                "category": "car",
                "value": 5000,
                "description": "A decent used car that gets you from A to B."
            },
            {
                "name": "New Economy Car",
                "category": "car",
                "value": 20000,
                "description": "A new, fuel-efficient economy car."
            },
            {
                "name": "Luxury Sedan",
                "category": "car",
                "value": 50000,
                "description": "A high-end luxury sedan with all the features."
            },
            {
                "name": "Sports Car",
                "category": "car",
                "value": 100000,
                "description": "A flashy sports car that turns heads."
            }
        ],
        "electronics": [
            {
                "name": "Smartphone",
                "category": "electronics",
                "value": 800,
                "description": "The latest smartphone with all the bells and whistles."
            },
            {
                "name": "Laptop",
                "category": "electronics",
                "value": 1500,
                "description": "A high-performance laptop for work and play."
            },
            {
                "name": "Gaming Console",
                "category": "electronics",
                "value": 500,
                "description": "The newest gaming console with a few games."
            },
            {
                "name": "Home Theater System",
                "category": "electronics",
                "value": 2000,
                "description": "A complete home theater setup with surround sound."
            }
        ],
        "investments": [
            {
                "name": "Stock Portfolio",
                "category": "investment",
                "value": 10000,
                "description": "A diversified portfolio of stocks."
            },
            {
                "name": "Savings Bond",
                "category": "investment",
                "value": 5000,
                "description": "A safe, long-term investment with guaranteed returns."
            },
            {
                "name": "Rental Property",
                "category": "investment",
                "value": 150000,
                "description": "A property that generates passive income."
            },
            {
                "name": "Small Business",
                "category": "investment",
                "value": 50000,
                "description": "A stake in a small local business."
            }
        ]
    }