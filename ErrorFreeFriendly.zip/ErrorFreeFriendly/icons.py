"""
SVG Icons for PyLife game
"""

# Main logo/icon
CROWN_ICON = """
<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
  <path d="M3 17L6 8L12 12L18 8L21 17H3Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
  <path d="M3 19H21" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
</svg>
"""

# Character stats icons
HEALTH_ICON = """
<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
  <path d="M19.5 13.5L12 21L4.5 13.5C3.16667 12.1667 2.5 10.5 2.5 8.5C2.5 6.5 3.16667 4.83333 4.5 3.5C5.83333 2.16667 7.5 1.5 9.5 1.5C11.5 1.5 13.1667 2.16667 14.5 3.5L12 6L9.5 3.5C8.16667 2.16667 6.5 2.16667 5.5 3.5C4.16667 4.5 4.16667 6.16667 4.5 7.5C4.83333 8.83333 5.5 10 6.5 11L12 16.5L17.5 11C18.5 10 19.1667 8.83333 19.5 7.5C19.8333 6.16667 19.8333 4.5 18.5 3.5C17.5 2.16667 15.8333 2.16667 14.5 3.5L12 6" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
</svg>
"""

HAPPINESS_ICON = """
<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
  <circle cx="12" cy="12" r="10" stroke="currentColor" stroke-width="1.5"/>
  <path d="M8 14C8.66667 15.3333 10 17 12 17C14 17 15.3333 15.3333 16 14" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
  <circle cx="9" cy="10" r="1" fill="currentColor"/>
  <circle cx="15" cy="10" r="1" fill="currentColor"/>
</svg>
"""

MONEY_ICON = """
<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
  <path d="M12 2C6.48 2 2 6.48 2 12C2 17.52 6.48 22 12 22C17.52 22 22 17.52 22 12C22 6.48 17.52 2 12 2ZM12 20C7.59 20 4 16.41 4 12C4 7.59 7.59 4 12 4C16.41 4 20 7.59 20 12C20 16.41 16.41 20 12 20Z" fill="currentColor"/>
  <path d="M12.5 7H10.5V13H12.5V7Z" fill="currentColor"/>
  <path d="M12.5 14H10.5V16H12.5V14Z" fill="currentColor"/>
</svg>
"""

INTELLIGENCE_ICON = """
<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
  <path d="M12 3V5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
  <path d="M19 12L21 12" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
  <path d="M3 12L5 12" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
  <path d="M12 19V21" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
  <path d="M17.6569 6.34315L16.2426 7.75736" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
  <path d="M16.2426 16.2426L17.6569 17.6569" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
  <path d="M7.75736 16.2426L6.34315 17.6569" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
  <path d="M6.34315 6.34315L7.75736 7.75736" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
  <circle cx="12" cy="12" r="4" stroke="currentColor" stroke-width="1.5"/>
</svg>
"""

APPEARANCE_ICON = """
<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
  <circle cx="12" cy="8" r="5" stroke="currentColor" stroke-width="1.5"/>
  <path d="M20 21C20 17.134 16.866 14 12 14C7.13401 14 4 17.134 4 21" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
</svg>
"""

# Event icons
EDUCATION_ICON = """
<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
  <path d="M12 2L2 7L12 12L22 7L12 2Z" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
  <path d="M2 17L12 22L22 17" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
  <path d="M2 12L12 17L22 12" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
</svg>
"""

CAREER_ICON = """
<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
  <rect x="2" y="7" width="20" height="14" rx="2" stroke="currentColor" stroke-width="1.5"/>
  <path d="M16 7V5C16 3.89543 15.1046 3 14 3H10C8.89543 3 8 3.89543 8 5V7" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
  <path d="M12 12V16" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
  <path d="M8 12H16" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
</svg>
"""

RELATIONSHIP_ICON = """
<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
  <circle cx="8" cy="7" r="4" stroke="currentColor" stroke-width="1.5"/>
  <circle cx="16" cy="7" r="4" stroke="currentColor" stroke-width="1.5"/>
  <path d="M5 21V17C5 15.8954 5.89543 15 7 15H9C10.1046 15 11 15.8954 11 17V21" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
  <path d="M13 21V17C13 15.8954 13.8954 15 15 15H17C18.1046 15 19 15.8954 19 17V21" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
</svg>
"""

ASSET_ICON = """
<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
  <path d="M3 9L12 4L21 9V20H3V9Z" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
  <path d="M9 20V12H15V20" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
</svg>
"""

RANDOM_EVENT_ICON = """
<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
  <path d="M2 12C2 17.5228 6.47715 22 12 22C17.5228 22 22 17.5228 22 12C22 6.47715 17.5228 2 12 2C6.47715 2 2 6.47715 2 12Z" stroke="currentColor" stroke-width="1.5"/>
  <path d="M12 7V13" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
  <circle cx="12" cy="16" r="1" fill="currentColor"/>
</svg>
"""

TRAVEL_ICON = """
<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
  <path d="M4 11C4 7.5 7.5 4 12 4C16.5 4 20 7.5 20 11C20 14.5 16.5 18 12 18C7.5 18 4 14.5 4 11Z" stroke="currentColor" stroke-width="1.5"/>
  <path d="M12 18V22" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
  <path d="M8 22H16" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
  <path d="M16 11C16 13.2091 14.2091 15 12 15C9.79086 15 8 13.2091 8 11C8 8.79086 9.79086 7 12 7C14.2091 7 16 8.79086 16 11Z" stroke="currentColor" stroke-width="1.5"/>
</svg>
"""

MARRIAGE_ICON = """
<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
  <circle cx="7" cy="8" r="4" stroke="currentColor" stroke-width="1.5"/>
  <circle cx="17" cy="8" r="4" stroke="currentColor" stroke-width="1.5"/>
  <path d="M12 14C12 14 7.5 16.5 5.5 20" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
  <path d="M12 14C12 14 16.5 16.5 18.5 20" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
  <path d="M12 9L12 21" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
</svg>
"""

# Action icons
ADVANCE_TIME_ICON = """
<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
  <circle cx="12" cy="12" r="10" stroke="currentColor" stroke-width="1.5"/>
  <path d="M12 6V12L16 14" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
</svg>
"""

SAVE_ICON = """
<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
  <path d="M19 21H5C3.89543 21 3 20.1046 3 19V5C3 3.89543 3.89543 3 5 3H16L21 8V19C21 20.1046 20.1046 21 19 21Z" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
  <path d="M17 21V13H7V21" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
  <path d="M7 3V8H15" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
</svg>
"""

LOAD_ICON = """
<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
  <path d="M4 6H2V20C2 21.1046 2.89543 22 4 22H18V20H4V6Z" fill="currentColor"/>
  <path d="M20 2H8C6.89543 2 6 2.89543 6 4V16C6 17.1046 6.89543 18 8 18H20C21.1046 18 22 17.1046 22 16V4C22 2.89543 21.1046 2 20 2Z" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
  <path d="M10 8H18" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
  <path d="M10 12H18" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
  <path d="M10 16H14" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
</svg>
"""

DELETE_ICON = """
<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
  <path d="M3 6H21" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
  <path d="M8 6V4C8 3.46957 8.21071 2.96086 8.58579 2.58579C8.96086 2.21071 9.46957 2 10 2H14C14.5304 2 15.0391 2.21071 15.4142 2.58579C15.7893 2.96086 16 3.46957 16 4V6M19 6V20C19 20.5304 18.7893 21.0391 18.4142 21.4142C18.0391 21.7893 17.5304 22 17 22H7C6.46957 22 5.96086 21.7893 5.58579 21.4142C5.21071 21.0391 5 20.5304 5 20V6H19Z" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
  <path d="M10 11V17" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
  <path d="M14 11V17" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
</svg>
"""