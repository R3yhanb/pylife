"""
Styling utilities for the PyLife game
"""

def get_progress_bar_style(value, color="blue"):
    """Generate HTML for a custom progress bar with given value and color"""
    return f"""
    <div style="width:100%; background-color:#444; height:10px; border-radius:5px; margin-top:5px;">
        <div style="width:{value}%; background-color:{color}; height:10px; border-radius:5px;"></div>
    </div>
    """

def get_stat_style(value):
    """Get color for a stat value (0-100)"""
    if value >= 80:
        return "#4CAF50"  # Green
    elif value >= 50:
        return "#FF9800"  # Orange
    else:
        return "#F44336"  # Red

def get_event_card_style(event_type="normal"):
    """Get CSS style for event cards based on event type"""
    base_style = "margin-bottom:10px; padding:10px; border-radius:5px;"
    
    if event_type == "positive":
        return f"{base_style} background-color:#1E3D2E;"  # Dark green
    elif event_type == "negative":
        return f"{base_style} background-color:#3D1E1E;"  # Dark red
    else:
        return f"{base_style} background-color:#273144;"  # Normal blue-gray
        
def get_css():
    """Get CSS styles for the app"""
    return """
    .main-header {
        text-align: center;
        font-size: 3rem;
        margin-bottom: 1rem;
        color: #4FC3F7;
    }
    .character-summary {
        margin-bottom: 1rem;
        padding: 1rem;
        border-radius: 5px;
        background-color: #1E2433;
    }
    .stat-container {
        display: flex;
        align-items: center;
        margin-bottom: 0.5rem;
    }
    .stat-icon {
        margin-right: 10px;
        width: 24px;
        height: 24px;
    }
    .stat-label {
        min-width: 100px;
    }
    .stat-value {
        margin-left: 10px;
    }
    .event-card {
        margin-bottom: 10px;
        padding: 10px;
        border-radius: 5px;
        background-color: #273144;
    }
    .game-over-text {
        text-align: center;
        font-size: 2rem;
        margin: 2rem 0;
        color: #FF5252;
    }
    .life-summary {
        max-width: 600px;
        margin: 0 auto;
        padding: 1rem;
        border-radius: 5px;
        background-color: #1E2433;
    }
    """